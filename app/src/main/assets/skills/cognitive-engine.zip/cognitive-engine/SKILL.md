---
name: cognitive-engine
description: "Orchestrates how an AI thinks and what it spends: multi-path divergence, evidence-bound convergence, coverage checks, token budgeting, self-improving strategy memory. Meta-skill: schedules what/how to think and how much to spend; produces no domain artifacts. Use when a task has 2+ plausible approaches to weigh, spans 3+ files / 5+ steps / 3+ hard constraints, carries irreversible impact, or yields output verifiable by tests/schema/scripts. Do NOT use for: deterministic single-step ops (conversion, rename, import sorting, known command); one-shot factual Q&A, translation, term lookup; solution already specified by the user; open-ended creative writing with no correctness criterion (poems, stories); tasks covered end-to-end by a specialist skill (pptx/docx/xlsx/pdf - defer to it); work under ~2k tokens; or when the user says just do it. Triggers: 多方案权衡, 系统性排查, 覆盖度检查, token 预算, 省钱, 自我进化, 复盘沉淀, reasoning budget, multi-path, coverage, cost-aware."
license: Proprietary. 见仓库 LICENSE.txt（发布门禁前补齐）
metadata:
  author: "skill-design-team"
  version: "0.1.0"
  mode: "prototype"
  compatibility: "Requires python3 (3.8+). No third-party packages. Zero network requirement. Cross-platform incl. Windows (scripts are pure Python stdlib; no shell pipeline required)."
---

> ⚠️ **原型未实现清单（v0.1.0）**：本原型已落地主链路的核心确定性脚本（gate_trigger / dedupe / coverage / claims / budget / strategy / init_state / confirm）与 L1 配置（`budget-bands.json` / `tech_spec.json` / `redlines.json` / `failure-modes.json` / `strategy-seeds.jsonl` / `signal-model.json`）。**以下声明为原型阶段未实现、转入 v0.2 的项**，按 PRD §10「不允许假装已实现」的硬要求如实列出：
> - **缺失脚本（11）**：`inventory.py`、`redline.py`、`consistency_check.py`、`receipt.py`、`pipeline.py`、`trace.py`、`cache.py`、`compress.py`、`redteam.py`、`failure.py`、`selftest.py`
> - **缺失红线执行器**：`redlines.json` 已定义 5 条 🔴 + 5 条 🟡 红线，但 `redline.py` 未实现 → 红线目前只有数据、无拦截
> - **缺失参考文件（L2/L3）**：`references/{WORKFLOW,TECH_SPEC,REDLINES,TAXONOMY,BUDGETING,COMPRESSION,STRATEGY_SCHEMA,STATE_SCHEMA,DEGRADATION,OUTPUT_CONTRACT}.md` 与 `assets/templates/{conclusion-table,receipt}.md` 均未生成 → §5「按阶段加载」表里的路径目前断链，需要细节时以 `budget-bands.json` / `tech_spec.json` / `signal-model.json` 为权威源
> - **缺失能力**：R4 断点续跑（`pipeline.py`）、T3 成本回执渲染（receipt.py）、M9 三处事实源一致性校验（consistency_check.py）、FM-07 红线漏放一票冻结（failure.py）

# Cognitive Engine（认知引擎）

> 元技能：不产出领域产物，产出「思考过程的组织方式 + 成本约束 + 可回滚的沉淀」。
> 命中专精技能时让位，只在对方出现多方案权衡 / 覆盖度风险 / 不可逆动作时叠加做外层校验。

## 0. 起步：两件事必须先做

**① 红线先于一切（🔴 Critical 常驻）**：本技能的任何动作都不得违反五条 Critical 红线
（不可逆未确认 / 敏感信息落盘 / 自改技能包 / 伪造证据 / 无确认发布）。
需要精确判据时读 `references/REDLINES.md`；机器判定走 `scripts/redline.py`。

**② 初始化 / 体检（幂等，任何会话都可重跑）**：

```
python3 scripts/init_state.py doctor            # 先看环境能力与待回填项
python3 scripts/init_state.py init --state-root <DIR>   # 首次使用：创建状态目录 + 装种子策略
```

状态默认落在 `$COGNITIVE_ENGINE_HOME`（缺省 `~/.cognitive-engine`），**绝不写入技能包**。
技能包是只读分发物：任何「进化」都只能落到状态目录，改动技能包必须生成 patch 提案交人工确认。

## 1. 主链路（6 节点，前一节点产出缺失不得进入下一节点）

| # | 阶段 | 入口条件 | 必跑脚本（确定性计算） | 退出标准（机器可校验） |
|---|---|---|---|---|
| 1 | 红线预检 | 任务已明确 | `redline.py check` | 无 🔴 命中；🟡 已 ack 或已处理 |
| 2 | 任务画像 / 门控 | 用户任务 T | `gate_trigger.py judge` | 产出含 `reason` 与分值的判定 JSON；不触发则**结束**（退出码 10） |
| 3 | 分级加载 | 已定 tier | `inventory.py select` | 产出加载清单；被加载文件后续须被证据引用 |
| 4 | 多视角发散 | tier 的 fanout | `strategy.py search` → `dedupe.py run` | `unique_ratio` ≥ 阈值且覆盖 ≥3 个视角维度 |
| 5 | 收敛 + 覆盖度 | 去重后候选 | `claims.py verify` → `coverage.py check` | 证据标注率 100%；覆盖率达标或**显式列出未覆盖项** |
| 6 | 沉淀 + 回执 | 结论成型 | `consistency_check.py run` → `receipt.py render` | 三处事实源一致；回执 5 行完整 |

全程由 `pipeline.py` 记录阶段状态以支持断点续跑，由 `trace.py` 落 Trace：

```
python3 scripts/pipeline.py begin  --task-file <path>            # 返回 run_id
python3 scripts/pipeline.py enter --run-id <RID> --stage gate    # 进入节点（校验前置）
python3 scripts/pipeline.py exit  --run-id <RID> --stage gate --artifact <file>
```

## 2. 脚本速查（所有脚本：`--help` 查看全部参数，`--selftest` 跑内嵌确定性自测）

| 脚本 | 职责 | 典型调用 |
|---|---|---|
| `init_state.py` | 状态初始化 / 迁移 / 体检 / 重置（重置需人工确认） | `init_state.py doctor` |
| `gate_trigger.py` | FP-01/02 触发门控与档位选择（含净收益预判） | `gate_trigger.py judge --task "<文本>"` |
| `budget.py` | FP-13 token 计量与预算闸门（metered/estimated 双通道） | `budget.py check --tier Standard --tokens 6500` |
| `inventory.py` | FP-14 分级加载选择与「加载但未引用」审计 | `inventory.py select --files <list.json> --budget 2000` |
| `dedupe.py` | FP-05 候选去重与互异率（禁止 LLM 目测） | `dedupe.py run --candidates <path>` |
| `coverage.py` | FP-07 覆盖度矩阵与缺口回填计数（≤2 轮） | `coverage.py check --gold <path> --conclusion <path>` |
| `claims.py` | FP-06/08 证据绑定校验与置信度分级 | `claims.py verify --claims <path>` |
| `strategy.py` | FP-10/12 策略检索、灰度、晋升、回滚 | `strategy.py search --task-text "..."` |
| `failure.py` | FP-11 失败模式归因（固定枚举 FM-01..FM-08） | `failure.py attribute --run-id <RID> --outcome rework` |
| `compress.py` | FP-16 无损上下文压缩（有损默认关闭） | `compress.py run --file <path>` |
| `redline.py` | FP-18 两级红线检查（🔴 停 / 🟡 ack） | `redline.py check --text "..."` |
| `confirm.py` | FP-20 不可逆动作确认关卡 | `confirm.py request --action --scope --rollback` |
| `consistency_check.py` | FP-19/M9 三处事实源一致性 | `consistency_check.py run` |
| `receipt.py` | FP-21 成本-收益回执 | `receipt.py render --run-id <RID>` |
| `pipeline.py` | FP-03 阶段编排、断点续跑、放弃标记 | `pipeline.py begin/enter/exit/abandon` |
| `trace.py` | Trace 落盘、校验、汇总（成本画像来源） | `trace.py emit/summary/validate` |
| `cache.py` | FP-17 缓存（**P2 桩，原型未启用**） | `cache.py status` |
| `redteam.py` | FP-22 红队对抗（**P2 桩，仅 Deep 档规划**） | `redteam.py status` |
| `selftest.py` | 一次性跑全部脚本的自测 | `selftest.py run` |

**Windows 说明**：一律 `python3 scripts/<名>.py ...`，不需要 bash，不含 shell 管道。
**退出码**：`0 OK / 1 内部错误 / 2 用法错误 / 3 待人工确认 / 4 预算熔断 / 5 命中🔴 / 6 命中🟡 / 7 状态已自愈 / 10 判定不触发 / 11 质量未达标`。

## 3. 硬规则（违反即不合格）

1. **确定性计算必须走脚本**：token 统计、去重相似度、覆盖率、hash、预算判定、缓存命中判定 —— 禁止 LLM 心算或目测（这既是可复现要求，也是最强的省钱杠杆）。
2. **`estimated` 不得冒充 `metered`**：没有宿主 usage 时，输出必须带 `source: estimated` 与置信度；成本降幅结论不得建立在估算样本上。
3. **缺证不说满**：每条结论断言必须挂 `evidence`（`file:line` / 命令输出 / 显式 `unverified`）；无源断言不准进结论区。
4. **缺口不静默**：覆盖度未达标必须先回填（≤2 轮），仍缺则显式列出未覆盖项并说明原因。
5. **不可逆动作必须过确认关卡**：产出「动作 / 影响范围 / 回滚方式」，拿到显式确认才执行；未确认而执行次数必须为 0。
6. **技能包只读**：进化产物只落状态目录；改技能包只能走 patch 提案 + 人工确认 + 可回滚。
7. **降级必须可见**：脚本不可用、状态损坏、计量降级等情况必须在输出中显式标注，静默降级 = 0 容忍。

## 4. 输出契约（每次任务必须包含 5 段，缺一不合格）

① 结论（含置信度） → ② 结论-证据对照表 → ③ 覆盖度矩阵 + 未覆盖项 → ④ 未验证声明 → ⑤ 成本-收益回执。
模板见 `assets/templates/conclusion-table.md` 与 `assets/templates/receipt.md`。

## 5. 按阶段加载（需要细节时再读，别一次全读）

| 你需要 | 读这个文件 |
|---|---|
| 流水线细节与分支、阶段退出标准 | `references/WORKFLOW.md` |
| 全部阈值/常量的值与依据（唯一定义处镜像） | `references/TECH_SPEC.md` |
| 红线精确判据与报告模板 | `references/REDLINES.md` |
| 术语精确映射（禁止同义词混用） | `references/TAXONOMY.md` |
| token 估算模型、校准回路、误差边界 | `references/BUDGETING.md` |
| 压缩动作清单（确定性 vs 判断区） | `references/COMPRESSION.md` |
| 策略库 schema、晋升/回滚机制 | `references/STRATEGY_SCHEMA.md` |
| 状态文件 schema（JSONL 字段说明） | `references/STATE_SCHEMA.md` |
| 降级路径矩阵 | `references/DEGRADATION.md` |
| 输出五段式契约与最小复现示例 | `references/OUTPUT_CONTRACT.md` |

> 以上均为 L2/L3 资源，**未读取前不占上下文**。先流转主干，缺什么再补什么。
