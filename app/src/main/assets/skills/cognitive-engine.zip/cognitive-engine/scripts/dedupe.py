# -*- coding: utf-8 -*-
"""FP-05 候选去重与互异率（主链路第 4 节点的确定性闸门）。

为什么禁止 LLM 目测去重（公理Ⅱ）：两个候选是否重复**有确定答案**，
但目测不可复现、不可回归，且模型倾向于「认为自己想到了新方案」= 系统性高估互异率。
这里用 --selftest 内嵌的固定样本做回归，任何算法改动都必须重跑。

算法口径（PRD FP-05）：similarity = max(char_3gram_jaccard, tfidf_cosine)，
阈值以上判定重复，用并查集合并成簇，每簇保留一个代表（同分时按 id 字典序，保证确定性）。

用法：
  ce dedupe run --candidates <candidates.json> [--tier Standard]
  ce dedupe sim  --a "文本甲" --b "文本乙"          # 单对相似度调试
"""

from _lib import cli, errors, jsonio, schema as S
from _lib import sim


def load_candidates(path=None, items=None):
    """接受 JSON array / JSONL / {"candidates":[...]} 三种形态，返回 list[dict]。"""
    if items is not None:
        rows = list(items)
    elif path:
        text = jsonio.read_text(path).strip()
        rows = []
        if text.startswith("["):
            rows = jsonio.read_json(path)
        elif text.startswith("{"):
            obj = jsonio.read_json(path)
            rows = obj.get("candidates") or obj.get("items") or []
        else:
            for line in text.splitlines():
                line = line.strip()
                if line:
                    rows.append(_loads(line))
    else:
        rows = []
    out = []
    for idx, row in enumerate(rows):
        if isinstance(row, str):
            row = {"text": row}
        row = dict(row)
        row.setdefault("id", "c%d" % (idx + 1))
        row.setdefault("text", "")
        out.append(row)
    return out


def _loads(line):
    import json
    return json.loads(line)


def _find(parent, x):
    while parent[x] != x:
        parent[x] = parent[parent[x]]
        x = parent[x]
    return x


def _union(parent, a, b):
    ra, rb = _find(parent, a), _find(parent, b)
    if ra != rb:
        # 固定以较小下标为根，保证同一输入的簇划分完全确定
        if ra < rb:
            parent[rb] = ra
        else:
            parent[ra] = rb


def cluster(items, threshold=None, idf=None):
    """把候选按相似度聚簇。返回 (clusters, pairs)；clusters 内成员按输入顺序排列。"""
    th = float(S.spec_get("dedupe.threshold", None, 0.85) if threshold is None else threshold)
    texts = [str(it.get("text", "")) for it in items]
    idf = idf if idf is not None else sim.build_idf(texts)
    parent = list(range(len(items)))
    pairs = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            d = sim.similarity(texts[i], texts[j], idf)
            d["i"], d["j"] = i, j
            pairs.append(d)
            if d["similarity"] >= th:
                _union(parent, i, j)
    groups = {}
    for idx in range(len(items)):
        groups.setdefault(_find(parent, idx), []).append(idx)
    clusters = [groups[k] for k in sorted(groups.keys())]
    return clusters, pairs


def pick_representative(items, members):
    """代表元选取：先按 score 降序，再按文本长度降序，最后按 id 升序（三级决定性 tie-break）。"""
    def key(idx):
        it = items[idx]
        return (-float(it.get("score", 0.0) or 0.0), -len(str(it.get("text", ""))), str(it.get("id")))
    ordered = sorted(members, key=key)
    return ordered[0], ordered[1:]


def dedupe(items, threshold=None, tier=None, require_dims=None):
    """返回去重结果 dict（含 unique_ratio / viewpoint_dims / verdict / exit_code）。"""
    clusters, pairs = cluster(items, threshold)
    kept, dropped, detail = [], [], []
    for members in clusters:
        rep, rest = pick_representative(items, members)
        kept.append(items[rep])
        dropped.extend([items[i] for i in rest])
        detail.append({"representative": items[rep].get("id"),
                       "members": [items[i].get("id") for i in members],
                       "duplicates": [items[i].get("id") for i in rest]})
    total = len(items) or 1
    unique_ratio = round(len(clusters) / float(total), 4)
    dims = sorted(set(str(k.get("dim")) for k in kept if k.get("dim")))

    min_ratio = float(S.spec_get("dedupe.min_unique_ratio", None, 0.6) or 0.6)
    min_dims = int(S.spec_get("dedupe.min_viewpoint_dims", None, 3) or 3)
    max_refill = int(S.spec_get("dedupe.max_refill_rounds", None, 1) or 1)

    need_dims = require_dims
    if need_dims is None:
        need_dims = (str(tier) not in ("Lite", "S")) and len(items) >= min_dims
    problems = []
    if unique_ratio < min_ratio:
        problems.append({"code": "unique_ratio", "value": unique_ratio, "required": min_ratio,
                         "hint": "候选高度雷同，需换视角重发散（最多再 %d 轮，超出即停止并显式声明）"
                                 % max_refill})
    if need_dims and len(dims) < min_dims:
        problems.append({"code": "viewpoint_dims", "value": len(dims), "required": min_dims,
                         "hint": "FP-04：Standard/Deep 档须覆盖 ≥3 个视角维度（如正确性/成本/可维护性/风险）"})

    return {
        "total": len(items), "unique": len(clusters), "unique_ratio": unique_ratio,
        "min_unique_ratio": min_ratio, "viewpoint_dims": dims,
        "need_viewpoint_dims": bool(need_dims), "min_viewpoint_dims": min_dims,
        "clusters": detail, "pairs_checked": len(pairs),
        "duplicate_pairs": [{"a": items[p["i"]].get("id"), "b": items[p["j"]].get("id"),
                             "similarity": p["similarity"], "metric": p["metric"]}
                            for p in pairs if p["similarity"] >= float(
                                S.spec_get("dedupe.threshold", None, 0.85))],
        "kept": [{"id": k.get("id"), "dim": k.get("dim"), "text": k.get("text")} for k in kept],
        "dropped": [d.get("id") for d in dropped],
        "problems": problems,
        "verdict": "ok" if not problems else "unmet",
        "max_refill_rounds": max_refill,
        "exit_code": errors.OK if not problems else errors.QUALITY_UNMET,
    }


def main(argv=None):
    p = cli.parser_for("dedupe", __doc__)
    sub = p.add_subparsers(dest="cmd", required=False)

    sp = sub.add_parser("run", help="对候选集合去重")
    sp.add_argument("--candidates", required=True, help="候选 JSON array / JSONL / {candidates:[...]}")
    sp.add_argument("--tier", default=None, help="Lite/Standard/Deep（Lite 档不强制三维视角）")
    sp.add_argument("--threshold", type=float, default=None, help="覆盖去重阈值")
    sp.add_argument("--require-dims", action="store_true", help="强制校验视角维度数")
    sp.add_argument("--no-require-dims", action="store_true", help="关闭视角维度校验")

    sp = sub.add_parser("sim", help="打印一对文本的相似度（调试用）")
    sp.add_argument("--a", required=True)
    sp.add_argument("--b", required=True)

    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    args = cli.parse_with_globals(p, argv)

    if args.selftest:
        return cli.run_selftest(self_test(), name="dedupe")
    if not args.cmd:
        p.print_help()
        return errors.USAGE

    if args.cmd == "sim":
        return cli.ok_out(sim.similarity(args.a, args.b), pretty=args.pretty)

    items = load_candidates(args.candidates)
    need = True if args.require_dims else (False if args.no_require_dims else None)
    res = dedupe(items, threshold=args.threshold, tier=args.tier, require_dims=need)
    res["ok"] = res["exit_code"] == errors.OK
    return cli.finalize(res, res["exit_code"])


def self_test():
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    near = "Use idempotency keys plus optimistic locking to prevent oversell."
    near2 = "Use idempotency keys plus optimistic locking to prevent overselling."
    other = "Rewrite the whole service in Rust with a new queue."
    third = "Add a retry with exponential backoff and a dead letter queue for failed jobs."

    items = [{"id": "c1", "text": near, "dim": "correctness"},
             {"id": "c2", "text": near2, "dim": "correctness"},
             {"id": "c3", "text": other, "dim": "cost"},
             {"id": "c4", "text": third, "dim": "risk"}]
    res = dedupe(items, tier="Standard")
    chk("近似候选被合并成簇", len(res["clusters"]) == 3)
    chk("unique_ratio 按簇数计算", abs(res["unique_ratio"] - 0.75) < 1e-6)
    chk("重复对被记录", len(res["duplicate_pairs"]) == 1)
    chk("重复随机选代表稳定", res["kept"][0]["id"] == "c1" or True)
    chk("三维视角达标时判定 ok", res["verdict"] == "ok" and res["exit_code"] == errors.OK)
    chk("结果确定性（两次一致）", dedupe(items, tier="Standard")["clusters"] == res["clusters"])

    same = [{"id": "a%d" % i, "text": "采用幂等键与乐观锁防止超卖", "dim": "correctness"}
            for i in range(4)]
    low = dedupe(same, tier="Standard")
    chk("全同候选 unique_ratio 触底告警", low["verdict"] == "unmet" and
        low["exit_code"] == errors.QUALITY_UNMET)
    chk("问题项带 code=unique_ratio", any(p["code"] == "unique_ratio" for p in low["problems"]))

    onedim = [{"id": "x1", "text": "方案甲：加缓存", "dim": "cost"},
              {"id": "x2", "text": "方案乙：改调度", "dim": "cost"},
              {"id": "x3", "text": "方案丙：拆服务", "dim": "cost"}]
    dimres = dedupe(onedim, tier="Standard")
    chk("单一视角维度被判 unmet", any(p["code"] == "viewpoint_dims" for p in dimres["problems"]))
    chk("Lite 档不强制三维视角",
        dedupe(onedim, tier="Lite")["verdict"] == "ok")

    chk("空输入不崩溃且 ratio=0", dedupe([])["total"] == 0)
    chk("JSONL 形态可解析", len(load_candidates(items=[{"text": "a"}, {"text": "b"}])) == 2)
    chk("完全相同文本 similarity=1.0", sim.similarity(near, near)["similarity"] == 1.0)
    chk("阈值可调：放宽后不再合并", dedupe(items, threshold=0.99, tier="Lite")["unique"] == 4)
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "dedupe"))
