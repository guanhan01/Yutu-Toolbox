# -*- coding: utf-8 -*-
"""环境与能力探测 + 降级登记。

为什么需要：跨平台宿主的 python3 可用性、标准库完整度、目录可写性都不可假设（PRD R5/D2/D4）。
原则：**能力缺失 → 降级并显式标注，绝不静默**（M12 静默降级 = 0）。

输出形态统一为 incidents 列表，供 trace 与回执消费。
"""

import os
import sys
import tempfile
from pathlib import Path


def python_info():
    return {"version": "%d.%d.%d" % sys.version_info[:3], "executable": sys.executable,
            "platform": sys.platform}


def has_stdlib_module(name):
    import importlib.util
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def can_write_dir(path):
    p = Path(path)
    try:
        p.mkdir(parents=True, exist_ok=True)
        probe = p / (".write-probe-%d" % os.getpid())
        probe.write_text("x", encoding="utf-8")
        probe.unlink()
        return True
    except Exception:
        return False


def probe(state_root=None, needed_modules=("json", "hashlib", "pathlib", "sqlite3")):
    """能力探测，返回 {"caps":..., "incidents":[...]}。"""
    incidents = []
    caps = {"python": python_info(), "modules": {}, "can_exec_scripts": True}
    for m in needed_modules:
        ok = has_stdlib_module(m)
        caps["modules"][m] = ok
        if not ok:
            level = "standard" if m == "sqlite3" else "critical"
            incidents.append({
                "id": "CAP-MODULE-MISSING",
                "module": m,
                "level": level,
                "degrade_to": ("JSONL+lockfile（默认路径，无影响）" if m == "sqlite3"
                               else "该能力不可用，相关计算转为显式标注的估算值"),
            })
    if state_root:
        writable = can_write_dir(Path(state_root))
        caps["state_writable"] = writable
        if not writable:
            incidents.append({
                "id": "CAP-STATE-READONLY",
                "level": "critical",
                "degrade_to": "进化引擎降级为「会话内有效」，不跨会话持久化，并在输出中显式声明",
            })
    return {"caps": caps, "incidents": incidents}


def emit_incidents(tracer, incidents, stage="precheck"):
    """把能力缺失写成 trace 事件与降级标记（不吞掉）。"""
    for inc in incidents or []:
        tracer.emit("capability_probe", stage=stage, status="degraded",
                    decision={"degraded": True, "why": "%s -> %s" % (inc.get("id"),
                                                                     inc.get("degrade_to"))},
                    metrics={}, extra={"incident": inc})


def self_test():
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    info = python_info()
    chk("python 版本可读", isinstance(info["version"], str) and info["version"].count(".") == 2)
    chk("json 模块存在", has_stdlib_module("json"))
    with tempfile.TemporaryDirectory() as td:
        chk("临时目录可写", can_write_dir(Path(td) / "sub"))
    chk("不可能存在的模块返回 False", not has_stdlib_module("definitely_not_a_module_xyz"))
    return checks
