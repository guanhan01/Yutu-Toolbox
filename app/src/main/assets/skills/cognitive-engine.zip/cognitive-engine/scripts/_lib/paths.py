# -*- coding: utf-8 -*-
"""路径解析层：技能包只读、状态外置、零平台假设。

三条硬约定（来自 PLATFORM_RESEARCH §1.2 / 主理人拍板 O-4 O-5）：
1. 技能包位置靠 __file__ 上溯自发现，**不使用任何宿主私有变量**（如 ${CLAUDE_SKILL_DIR}）；
2. 状态**默认**落用户目录 $CE_HOME，**绝不**落在技能包内；仓库级状态仅 opt-in（环境变量 CE_REPO_STATE=1）；
3. 全部用 pathlib，Windows 一等公民，禁止字符串拼路径。
"""

import os
import sys
from pathlib import Path

SKILL_MARKER = "SKILL.md"
STATE_DIRNAME = ".cognitive-engine"
REPO_STATE_DIRNAME = ".ce-state"

# 允许 CI/评测注入状态根（齐回归做无污染测试时用）
ENV_HOME = "COGNITIVE_ENGINE_HOME"
ENV_REPO_STATE = "CE_REPO_STATE"


def skill_root(start=None):
    """自发现技能包根目录：从本文件向上找含 SKILL.md 的目录。"""
    here = Path(start or __file__).resolve()
    for parent in [here] + list(here.parents):
        if (parent / SKILL_MARKER).exists():
            return parent
    raise RuntimeError("未找到技能包根目录（缺少 %s）：%s" % (SKILL_MARKER, here))


def scripts_dir():
    return skill_root() / "scripts"


def references_dir():
    return skill_root() / "references"


def assets_dir():
    return skill_root() / "assets"


def ce_home():
    """状态根目录（用户级）。

    优先级：显式环境变量 > 用户HOME下 .cognitive-engine
    """
    env = os.environ.get(ENV_HOME, "").strip()
    if env:
        return Path(env).expanduser()
    return Path.home() / STATE_DIRNAME


def repo_state_root(cwd=None):
    """仓库级状态根（仅 opt-in）。返回 None 表示未开启或不处于仓库中。"""
    if os.environ.get(ENV_REPO_STATE, "").strip() != "1":
        return None
    base = Path(cwd or os.getcwd()).resolve()
    for parent in [base] + list(base.parents):
        if (parent / ".git").exists():
            return parent / REPO_STATE_DIRNAME
    return None


def state_root(explicit=None, cwd=None):
    """统一入口：显式传入 > 仓库级 opt-in > 用户级。"""
    if explicit:
        return Path(explicit).expanduser()
    return repo_state_root(cwd) or ce_home()


# ---------------- 状态目录内的标准布局 ----------------

def ensure_dir(path):
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def state_json(root):
    return Path(root) / "state.json"


def runs_jsonl(root):
    return Path(root) / "runs.jsonl"


def trace_dir(root):
    return Path(root) / "trace"


def trace_file(root, run_id):
    return trace_dir(root) / ("%s.jsonl" % run_id)


def run_dir(root, run_id):
    return Path(root) / "runs" / run_id


def run_state_json(root, run_id):
    return run_dir(root, run_id) / "state.json"


def strategies_jsonl(root):
    return Path(root) / "strategies.jsonl"


def experiences_jsonl(root):
    """§11.1 经验日志：append-only 不可变证据链（失败样本永不删除）。"""
    return Path(root) / "experiences.jsonl"


def policies_jsonl(root):
    """§11.1 八量派生台账（由脚本从经验日志+Trace 计算写入，可重建）。"""
    return Path(root) / "policies.jsonl"


def strategies_dir(root):
    return Path(root) / "strategies"


def strategy_index_md(root):
    return strategies_dir(root) / "INDEX.md"


def pending_dir(root):
    return Path(root) / "pending"


def cache_dir(root):
    return Path(root) / "cache"


def quarantine_dir(root):
    return Path(root) / "quarantine"


def backups_dir(root):
    return Path(root) / "backups"


def calibration_json(root):
    return Path(root) / "calibration.json"


def handoff_md(root):
    return Path(root) / "HANDOFF.md"


def ensure_layout(root):
    """创建完整状态目录骨架，返回新建的路径清单。"""
    created = []
    targets = [
        root, run_dir(root, "_keep"), trace_dir(root), strategies_dir(root),
        pending_dir(root), cache_dir(root), quarantine_dir(root), backups_dir(root),
    ]
    for t in targets:
        p = Path(t)
        if not p.exists():
            ensure_dir(p)
            created.append(str(p))
    return created


def rel_to_root(path, root):
    """把绝对路径转成相对状态根的相对路径（用于跨机器可移植的记录）。"""
    try:
        return str(Path(path).resolve().relative_to(Path(root).resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def bootstrap_sys_path():
    """让 `_lib` 可被导入：无论以脚本还是模块形式运行都成立。"""
    sd = scripts_dir()
    if str(sd) not in sys.path:
        sys.path.insert(0, str(sd))
