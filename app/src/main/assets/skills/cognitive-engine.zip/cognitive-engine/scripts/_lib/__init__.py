# -*- coding: utf-8 -*-
"""cognitive-engine 脚本公共库（零第三方依赖，Python 3.8+）。

分层：
  errors  - 退出码与异常语义（所有脚本共用）
  paths   - 路径解析（技能包只读、状态外置、跨平台）
  jsonio  - 原子写 / 备份 / lockfile / JSONL
  schema  - 版本号与 tech_spec 单一事实源访问
  tokens  - token 估算与校准（禁止 LLM 心算）
  sim     - 确定性相似度（去重/早停的度量基础）
  trace   - 结构化轨迹落盘与汇总（可画像、可回放）
  env     - 能力探测与降级登记（降级必须显式）

使用约定：所有脚本通过 `_lib` 访问公共能力，禁止自行实现 hash / 原子写 / 相似度，
以保证「同一算法只有一个实现」（否则一致性校验无意义）。
"""

from . import cli, errors, jsonio, paths, schema, sim, tokens, trace, env  # noqa: F401

__all__ = ["cli", "errors", "jsonio", "paths", "schema", "sim", "tokens", "trace", "env"]
