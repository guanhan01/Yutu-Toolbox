# -*- coding: utf-8 -*-
"""cognitive-engine 统一错误与退出码约定。

为什么单独成模块：所有脚本必须共用同一套退出码语义，否则宿主/调用方无法机器判定。
退出码 0 表示「正常」；其余分三类：
  - 2xx 段（这里用 2 / 3 / 4 / 5 / 6）：执行异常类
  - 10 / 11：决策类（不是错误，是判定结果为「否」）
"""

# ---- 执行异常类 ----
OK = 0                 # 成功
UNEXPECTED = 1         # 未预期异常（脚本内部错误）
USAGE = 2              # 参数/输入校验失败（用法错误）
NEED_CONFIRM = 3       # 不可逆动作待人工确认（硬关卡，未确认不执行）
BUDGET_BREACH = 4      # 预算熔断
REDLINE_CRITICAL = 5   # 命中 🔴 Critical 红线
REDLINE_STANDARD = 6   # 命中 🟡 Standard 红线（需 ack）
STATE_CORRUPT = 7      # 状态文件损坏（已自动隔离/重建）

# ---- 决策类（非错误）----
NO_TRIGGER = 10        # 门控判定：本任务不触发
QUALITY_UNMET = 11     # 质量未达标（如覆盖率/互异率未达标），需回填或显式声明

_DECISION_CODES = (NO_TRIGGER, QUALITY_UNMET)


class CEError(Exception):
    """带退出码的技能内异常。"""

    def __init__(self, message, exit_code=UNEXPECTED, **detail):
        Exception.__init__(self, message)
        self.message = message
        self.exit_code = exit_code
        self.detail = detail


def is_decision(code):
    """判定该退出码是否属于「决策结论」而非「执行失败」。"""
    return code in _DECISION_CODES


def describe(code):
    return {
        OK: "OK",
        UNEXPECTED: "UNEXPECTED_ERROR",
        USAGE: "USAGE_ERROR",
        NEED_CONFIRM: "NEED_CONFIRM",
        BUDGET_BREACH: "BUDGET_BREACH",
        REDLINE_CRITICAL: "REDLINE_CRITICAL",
        REDLINE_STANDARD: "REDLINE_STANDARD",
        STATE_CORRUPT: "STATE_CORRUPT_RECOVERED",
        NO_TRIGGER: "NO_TRIGGER(decision)",
        QUALITY_UNMET: "QUALITY_UNMET(decision)",
    }.get(code, "UNKNOWN(%s)" % code)
