# -*- coding: utf-8 -*-
"""FP-13 预算闸门：三轨分离 + 三档 + 三水位（PRD §11.2 定稿实现）。

这是整个技能里**唯一允许说「钱不够了」的模块**，所以它的取值必须全部可追溯：

- **判据轨 = chars**（脚本 len()，精确、零误差、跨平台一致）——唯一硬判据；
- **显示轨 = tokens_est**（带 confidence + method）——只用于回执与相对排序；
- **校准轨 = tokens_real**（宿主 usage）——有则最高优先级，并回写校准 α。

三条保守规则（§11.2.4）在这里逐行落地：
  R-保守1  SAFETY 随 confidence 与 CJK 占比变化，且只向上取整（永不高估预算余量）
  R-保守2  双轨取严：chars 越界 **或** tokens 越界 => 判定越界
  R-保守3  confidence=low 的 token 数不得用于 M4 降幅结论（输出字段 may_claim_savings 强制 False）

用法：
  ce budget check --band M --chars-in 9000 --chars-out 4200 --tokens-in 3000
  ce budget check --band M --text-file <path> --action diverge      # 由文本自动算 chars/tokens
  ce budget check --band S --chars-in 8000 --source metered --metered-tokens 9000
  ce budget calibrate --text-file <path> --metered-tokens 8123      # 真值回写校准
  ce budget case                                                    # 看当前计量情形 A/B/C/D
"""

import math
import sys

from _lib import cli, errors, jsonio, paths as P, schema as S
from _lib import tokens as TK

DRIFT_FREEZE_P50 = 0.25     # §11.2.4 情形 D 的阈值（|est-real|/real 的 p50）
DRIFT_MIN_SAMPLES = 5


def _ceil(x):
    return int(math.ceil(float(x)))


def load_meter_state(state_root):
    """读取 calibration.json；缺失返回空态（**不静默造真值**）。"""
    cal = TK.load_calibration(state_root)
    cal.setdefault("n_samples", 0)
    cal.setdefault("alpha", {c: 1.0 for c in ("en", "code", "json", "cjk")})
    return cal


def metering_case(source="estimated", confidence=None, calibration=None, active_override=None):
    """判定当前计量情形 A/B/C/D。返回 {"case","gate","behavior","reason","confidence"}。

    判定顺序有意为之：**D（冻结）优先于 A**——即使宿主这次给了真值，只要历史误差
    已经证明估算器不可信，token 轨就必须继续冻结（防止"偶尔报一次真值"就把闸门资格还回来）。
    """
    cfg = S.band_cfg().get("metering_cases") or {}
    cal = calibration or {}
    n = int(cal.get("n_samples", 0) or 0)
    drift = cal.get("drift_p50")
    conf = confidence or ("high" if n >= int(S.spec_get("token_model.calibration.min_samples_high_confidence",
                                                        None, 20) or 20) else "low")
    if n >= DRIFT_MIN_SAMPLES and drift is not None and float(drift) > DRIFT_FREEZE_P50:
        node = cfg.get("D") or {}
        return {"case": "D", "gate": node.get("gate", "chars_only"),
                "behavior": node.get("behavior", ""), "confidence": "frozen",
                "reason": "n=%d 且 |est-real|/real p50=%.3f > %.2f -> 冻结 token 轨"
                          % (n, float(drift), DRIFT_FREEZE_P50)}
    if str(source) == "metered":
        node = cfg.get("A") or {}
        return {"case": "A", "gate": node.get("gate", "hard"), "behavior": node.get("behavior", ""),
                "confidence": "metered", "reason": "宿主提供了 metered usage"}
    if str(conf) == "high":
        node = cfg.get("B") or {}
        return {"case": "B", "gate": node.get("gate", "soft"), "behavior": node.get("behavior", ""),
                "confidence": "high", "reason": "已校准（n=%d >= 20）" % n}
    node = cfg.get("C") or {}
    return {"case": "C", "gate": node.get("gate", "soft+confirm"), "behavior": node.get("behavior", ""),
            "confidence": "low", "reason": "未校准（n=%d < 20），跨平台默认情形" % n}


def _safety_for(confidence, cjk_ratio):
    coefficient, why = TK.safety_coefficient(confidence, cjk_ratio)
    if coefficient is None:  # 配置缺失时的显式降级（不拍值，回落 tech_spec 并在输出标注）
        coefficient = float(S.spec_get("token_model.safety.base", None, 1.15) or 1.15)
        return coefficient, (why + " -> SAFETY %.2f" % coefficient)
    return coefficient, why


def check_budget(band, chars_in=0, chars_out=0, tokens_in=0, tokens_out=0, source="estimated",
                 confidence=None, cjk_ratio=None, action="converge", calibration=None,
                 active_override=None, planned_band=None, state_root=None):
    """核心判定。返回 dict，含 decision/usage_pct/water_level/exit_code。**纯函数**（除读配置外）。"""
    code = S.band_get(band, "band", None)
    if code is None:
        raise errors.CEError("未知档位：%r（应为 S/M/L 或 Lite/Standard/Deep）" % band, errors.USAGE)
    cfg = S.band_cfg()
    p1_active = active_override or (cfg.get("p1_decision") or {}).get("active") or "dual_track"
    cap_chars = int(S.band_get(code, "cap_chars", None) or 0)
    cap_tokens = int(S.band_get(code, "cap_tokens", None) or 0)
    track = list(cfg.get("judgment_track") or ["chars"])
    if p1_active == "chars_only":
        track = ["chars"]

    case = metering_case(source, confidence, calibration, active_override)
    conf = case["confidence"]
    frozen = (case["case"] == "D")

    chars_used = int(chars_in) + int(chars_out)
    tokens_raw = int(tokens_in) + int(tokens_out)

    # R-保守1：只有估算轨需要乘 SAFETY；metered 与 frozen 不乘（前者是真值，后者已禁用 token 轨）
    if source == "metered" or frozen:
        tokens_used = tokens_raw
        safety, why = 1.0, "metered 或 token 轨冻结 -> 不应用 SAFETY"
    else:
        if cjk_ratio is None:
            cjk_ratio = 0.0
        safety, why = _safety_for(conf, float(cjk_ratio))
        tokens_used = _ceil(tokens_raw * safety)

    ratio_chars = (chars_used / float(cap_chars)) if cap_chars else 0.0
    ratio_tokens = (tokens_used / float(cap_tokens)) if cap_tokens else 0.0
    apply_tokens = (not frozen) and p1_active != "chars_only"

    # R-保守2：双轨取严
    if apply_tokens:
        usage_pct = max(ratio_chars, ratio_tokens)
        breach = (chars_used > cap_chars) or (tokens_used > cap_tokens)
    else:
        usage_pct = ratio_chars
        breach = chars_used > cap_chars

    levels = S.band_water_levels()
    w1 = float((levels.get("W1") or {}).get("ratio", 0.8))
    w2 = float((levels.get("W2") or {}).get("ratio", 1.0))
    w3 = float((levels.get("W3") or {}).get("ratio", 1.2))

    out = {
        "band": code, "tier": S.band_tier(code),
        "planned_band": S.band_get(planned_band, "band", None) if planned_band else code,
        "downgraded_from_planned": bool(planned_band and
                                        S.band_get(planned_band, "band", None) != code),
        "metering_case": case,
        "track": {"judgment": track, "token_track_applied": apply_tokens,
                  "p1_active": p1_active,
                  "note": "判据轨=chars（精确）；token 轨%s" % ("参与双轨取严" if apply_tokens
                                                        else "已禁用，仅显示")},
        "usage": {"chars_used": chars_used, "chars_cap": cap_chars, "chars_ratio": round(ratio_chars, 4),
                  "tokens_used": tokens_used, "tokens_raw": tokens_raw, "tokens_cap": cap_tokens,
                  "tokens_ratio": round(ratio_tokens, 4),
                  "tokens_source": source, "tokens_confidence": conf, "safety": safety,
                  "safety_rule": why, "usage_pct": round(usage_pct, 4)},
        "breach": bool(breach),
        # R-保守3：只有 metered 真值（情形 A）允许进入省钱类结论
        "may_claim_savings": (case["case"] == "A"),
        "priority_note": cfg.get("priority_declaration", ""),
        "action": action,
    }

    # ---- 三水位递进 ----
    if usage_pct >= w3:
        out.update({"decision": "circuit_break", "water_level": "W3",
                    "exit_code": errors.BUDGET_BREACH,
                    "reason": "用量 %.0f%% >= W3(%.0f%%) —— 硬熔断" % (usage_pct * 100, w3 * 100),
                    "required_output": ["current_best", "unfinished_list", "cost_receipt",
                                        "breach_reason"],
                    "must_not": ["静默截断输出", "死循环重试", "假装已完成",
                                 "把未完成项伪装成已完成"],
                    "next_hint": "建议下次降低档位或不触发"})
        return out

    if usage_pct >= w2:
        if case["case"] == "C":
            next_band, floor = S.band_downgrade(code)
            opts = ([{"id": 1, "label": "降级到 %s 档继续" % next_band,
                      "cmd": "budget.py check --band %s ..." % next_band}]
                    if not floor else
                    [{"id": 1, "label": "已是最小档 %s，无法降级" % code, "available": False}])
            out.update({"decision": "need_user_confirm", "water_level": "W2",
                        "exit_code": errors.NEED_CONFIRM,
                        "reason": ("情形 C（confidence=low）触顶：%.0f%% —— 严禁静默切换路径，"
                                   "必须请求用户确认" % (usage_pct * 100)),
                        "options": (opts + [
                            {"id": 2, "label": "立即出结论（当前最优 + 未完成项清单）"},
                            {"id": 3, "label": "用户显式追加预算"}]),
                        "cannot_downgrade": bool(floor),
                        "must_confirm": True})
            return out
        next_band, floor = S.band_downgrade(code)
        if floor:
            out.update({"decision": "circuit_break", "water_level": "W2_floor",
                        "exit_code": errors.BUDGET_BREACH,
                        "reason": "已在最小档 %s 且用量 %.0f%% >= 100%% —— 按 §11.2.5 直接进 W3"
                                  % (code, usage_pct * 100),
                        "required_output": ["current_best", "unfinished_list", "cost_receipt",
                                            "breach_reason"]})
            return out
        out.update({"decision": "downgrade", "water_level": "W2", "exit_code": errors.OK,
                    "reason": "情形 %s：用量 %.0f%% >= 100%%，自动降一档" % (case["case"], usage_pct * 100),
                    "downgrade_to": next_band,
                    "declare": "已降级（估算口径，confidence=%s）" % conf,
                    "fanout_after": S.band_get(next_band, "fanout", None)})
        return out

    if usage_pct >= w1:
        allow_diverge = (str(action) != "diverge")
        out.update({"decision": "warning_freeze_fanout", "water_level": "W1",
                    "exit_code": errors.OK,
                    "reason": "用量 %.0f%% >= W1(%.0f%%) —— 冻结扇出，只收敛不发散"
                              % (usage_pct * 100, w1 * 100),
                    "freeze_fanout": True, "allow": allow_diverge,
                    "mode": "converge_only"})
        return out

    out.update({"decision": "ok", "water_level": "W0", "exit_code": errors.OK,
                "reason": "用量 %.0f%% < W1(%.0f%%)" % (usage_pct * 100, w1 * 100),
                "freeze_fanout": False, "allow": True,
                "headroom_chars": max(0, cap_chars - chars_used)})
    return out


def calibrate(state_root, text=None, real_tokens=0, classes=None):
    """用宿主真值回写校准（校准轨落地）。返回 (calibration, drift_info)。"""
    cal, info = TK.update_calibration(str(state_root), text or "", int(real_tokens), classes)
    after = metering_case("estimated", None, cal)
    info["case_after"] = after["case"]
    info["drift_p50"] = cal.get("drift_p50")
    info["confidence_after"] = after["confidence"]
    return cal, info


def main(argv=None):
    p = cli.parser_for("budget", __doc__)
    sub = p.add_subparsers(dest="cmd", required=False)

    sp = sub.add_parser("check", help="预算闸门判定（主入口）")
    sp.add_argument("--band", default=None, help="S|M|L 或 Lite|Standard|Deep")
    sp.add_argument("--tier", default=None, help="同 --band")
    sp.add_argument("--chars-in", type=int, default=0)
    sp.add_argument("--chars-out", type=int, default=0)
    sp.add_argument("--tokens-in", type=int, default=0, help="输入侧 token（随 --source 释义）")
    sp.add_argument("--tokens-out", type=int, default=0)
    sp.add_argument("--text-file", default=None, help="直接用文件算 chars 与 tokens_est（脚本算，禁止心算）")
    sp.add_argument("--source", default="estimated", choices=["metered", "estimated"])
    sp.add_argument("--confidence", default=None, choices=["low", "high"])
    sp.add_argument("--cjk-ratio", type=float, default=None, help="覆盖 CJK 占比（影响 SAFETY）")
    sp.add_argument("--action", default="converge", choices=["converge", "diverge", "backfill"])
    sp.add_argument("--planned-band", default=None, help="原计划档位（用于判定是否已降档）")
    sp.add_argument("--p1-override", default=None, choices=["dual_track", "chars_only"],
                    help="临时切换 P-1 口径（默认读 budget-bands.json 的 active）")

    sub.add_parser("case", help="输出当前计量情形 A/B/C/D 与依据")
    sub.add_parser("bands", help="输出三档上限与三水位")

    sp = sub.add_parser("calibrate", help="真值回写校准（Calibration 轨）")
    sp.add_argument("--text-file", default=None)
    sp.add_argument("--text", default="")
    sp.add_argument("--metered-tokens", type=int, required=True, help="宿主返回的真实 token 数")

    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    args = cli.parse_with_globals(p, argv)

    if args.selftest:
        return cli.run_selftest(self_test(), name="budget")
    if not args.cmd:
        p.print_help()
        return errors.USAGE

    root = cli.resolve_state(args)
    cal = load_meter_state(str(root))

    if args.cmd == "case":
        return cli.ok_out({"calibration": {"n_samples": cal.get("n_samples"),
                                           "drift_p50": cal.get("drift_p50")},
                           "case": metering_case("estimated", None, cal)}, pretty=args.pretty)

    if args.cmd == "bands":
        rows = []
        for code in ("S", "M", "L"):
            rows.append({"band": code, "tier": S.band_tier(code),
                         "mid_tokens": S.band_get(code, "mid_tokens", None),
                         "cap_tokens": S.band_get(code, "cap_tokens", None),
                         "cap_chars": S.band_get(code, "cap_chars", None),
                         "fanout": S.band_get(code, "fanout", None)})
        return cli.ok_out({"bands": rows, "water_levels": S.band_water_levels()}, pretty=args.pretty)

    if args.cmd == "calibrate":
        text = args.text
        if args.text_file:
            text = jsonio.read_text(args.text_file)
        new_cal, info = calibrate(str(root), text, args.metered_tokens)
        return cli.ok_out({"calibration": {"n_samples": new_cal.get("n_samples"),
                                           "drift_p50": new_cal.get("drift_p50"),
                                           "last_ratio": new_cal.get("last_ratio")},
                           "info": info}, pretty=args.pretty)

    band = args.band or args.tier
    if not band:
        raise errors.CEError("必须提供 --band 或 --tier", errors.USAGE)
    chars_in, chars_out = args.chars_in, args.chars_out
    tokens_in, tokens_out = args.tokens_in, args.tokens_out
    cjk_ratio = args.cjk_ratio
    if args.text_file:
        est = TK.estimate_file(args.text_file, state_root=str(root))
        chars_in += int(est["chars"])
        tokens_in += int(est["tokens"])
        if cjk_ratio is None:
            cjk_ratio = float(est.get("cjk_ratio") or 0.0)
    res = check_budget(band, chars_in=chars_in, chars_out=chars_out, tokens_in=tokens_in,
                       tokens_out=tokens_out, source=args.source, confidence=args.confidence,
                       cjk_ratio=cjk_ratio, action=args.action,
                       calibration=cal, active_override=args.p1_override,
                       planned_band=args.planned_band, state_root=str(root))
    res["ok"] = res.get("exit_code", errors.OK) == errors.OK
    return cli.finalize(res, res.get("exit_code", errors.OK))


def self_test():
    checks = []
    import tempfile

    def chk(name, cond):
        checks.append((name, bool(cond)))

    # 基线：M 档 30,000 字符上限
    ok = check_budget("M", chars_in=5000, chars_out=2000, tokens_in=1500, tokens_out=800)
    chk("未触警时 decision=ok", ok["decision"] == "ok" and ok["exit_code"] == errors.OK)
    chk("W0 允许发散", ok["allow"] is True and ok["freeze_fanout"] is False)

    w1 = check_budget("M", chars_in=24000, chars_out=1000, tokens_in=1000, tokens_out=0)
    chk(">=80% 触发 W1 冻结扇出", w1["water_level"] == "W1" and w1["freeze_fanout"] is True)
    chk("W1 下申请发散被拒",
        check_budget("M", chars_in=25000, action="diverge")["allow"] is False)
    chk("W1 下收敛仍允许", check_budget("M", chars_in=24000, action="converge")["allow"] is True)

    # 情形 C（未校准）触顶 => 必须问用户，绝不静默
    c_case = metering_case("estimated", "low", {"n_samples": 0})
    chk("未校准被判为情形 C", c_case["case"] == "C" and c_case["gate"] == "soft+confirm")
    w2c = check_budget("S", chars_in=8000, tokens_in=2000, source="estimated", confidence="low")
    chk("情形 C 触顶需用户确认(退出码3)", w2c["decision"] == "need_user_confirm" and
        w2c["exit_code"] == errors.NEED_CONFIRM)
    chk("情形 C 给出三个选项", len(w2c.get("options", [])) == 3)

    # 情形 B（已校准）触顶 => 自动降一档
    b_cal = {"n_samples": 25, "drift_p50": 0.05}
    b_case = metering_case("estimated", None, b_cal)
    chk("已校准n>=20被判为情形 B", b_case["case"] == "B" and b_case["confidence"] == "high")
    w2b = check_budget("M", chars_in=31000, tokens_in=1000, calibration=b_cal)
    chk("情形 B 触顶自动降档到 S", w2b["decision"] == "downgrade" and w2b["downgrade_to"] == "S")
    chk("降档必须带声明", "已降级" in (w2b.get("declare") or ""))

    # 情形 A（metered）=> 硬闸门 + 允许省钱结论
    a_case = metering_case("metered", None, {})
    chk("metered 判为情形 A", a_case["case"] == "A" and a_case["gate"] == "hard")
    a_res = check_budget("S", chars_in=100, tokens_in=2900, tokens_out=200, source="metered")
    chk("metered 越界按 token 判", a_res["breach"] is True or a_res["usage"]["usage_pct"] > 1.0)
    chk("R-保守3：只有情形 A 允许省钱结论", a_res["may_claim_savings"] is True and
        ok["may_claim_savings"] is False)

    # 情形 D（误差超阈值）=> 冻结 token 轨
    d_cal = {"n_samples": 8, "drift_p50": 0.42}
    chk("误差 p50>25% 判为情形 D", metering_case("estimated", None, d_cal)["case"] == "D")
    d_res = check_budget("M", chars_in=6000, tokens_in=99999, calibration=d_cal)
    chk("情形 D 冻结 token 轨（不判 token 越界）",
        d_res["metering_case"]["confidence"] == "frozen" and d_res["decision"] == "ok")
    chk("情形 D 输出标注 tokens_method=disabled",
        d_res["track"]["token_track_applied"] is False)

    # W3 硬熔断
    w3 = check_budget("M", chars_in=40000, chars_out=0, tokens_in=0)
    chk(">=120% 硬熔断(退出码4)", w3["decision"] == "circuit_break" and
        w3["exit_code"] == errors.BUDGET_BREACH)
    chk("熔断要求四项输出", len(w3.get("required_output", [])) == 4)
    chk("最小档再触顶直接熔断",
        check_budget("S", chars_in=7600, calibration=b_cal)["decision"] in
        ("circuit_break", "downgrade"))

    # 双轨取严：字符没超但 token 超也算越界
    strict = check_budget("S", chars_in=1000, tokens_in=12000, tokens_out=0, source="metered")
    chk("R-保守2 双轨取严：token 单侧越界即算越界", strict["breach"] is True)

    # 只降不升：planned L -> 实际 S 标记为已降档
    dg = check_budget("S", chars_in=100, planned_band="L", tokens_in=0)
    chk("降档被记录（planned vs used）", dg["downgraded_from_planned"] is True)

    # P-1 开关：chars_only 下 token 上限仅显示
    co = check_budget("M", chars_in=1000, tokens_in=29000, source="metered",
                      active_override="chars_only")
    chk("P-1 切到 chars_only 后 token 轨不参与判定",
        co["track"]["token_track_applied"] is False and co["decision"] == "ok")

    # 校准回路（临时目录，不污染真实状态）
    with tempfile.TemporaryDirectory() as td:
        text = "def foo(x):\n    return x + 1\n" * 20
        new_cal, info = calibrate(td, text, 210)
        chk("校准写入 n_samples+1", int(new_cal["n_samples"]) == 1)
        chk("校准记录误差", isinstance(info.get("ratio"), float))
        chk("校准文件落盘", P.calibration_json(td).exists())
        after = metering_case("estimated", None, new_cal)
        chk("样本不足时仍为情形 C", after["case"] == "C")

    try:
        check_budget("XX", chars_in=1)
        chk("未知档位报错", False)
    except errors.CEError as exc:
        chk("未知档位报用法错误(2)", exc.exit_code == errors.USAGE)

    return checks


if __name__ == "__main__":
    sys.exit(cli.safe_dispatch(main, None, "budget"))
