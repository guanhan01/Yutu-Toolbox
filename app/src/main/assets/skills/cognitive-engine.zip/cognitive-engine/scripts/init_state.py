# -*- coding: utf-8 -*-
"""状态初始化 / 迁移 / 体检（首要执行的服务 invariants）。

职责：
- 首次运行创建 $CE_HOME 完整骨架 + state.json（单一事实源清单）；
- 版本迁移：遇到旧 schema 时先备份到 backups/，再升级，**不静默丢弃**；
- 安装种子策略并重建派生视图（保证策略库冷启动可用）；
- 能力探测结果写入 state.json（哪些能力缺失 -> 降级为什么，M12 要求显式可见）。
- `reset` 为不可逆动作，走 FP-20 确认关卡（默认只生成提案，退出码 3）。

用法：
  ce init [--state-root DIR] [--run-id RID]
  ce doctor [--state-root DIR]
  ce reset --confirmed-by <人> --token <token> [--state-root DIR]
"""

import datetime

from _lib import cli, env, errors, jsonio, paths as P, schema as S
from _lib import trace as TR
import strategy as _strategy

STATE_LAYOUT_VERSION = 2  # 迁移用的布局版本（v1: 无 quarantine/策略目录）


def _now():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def build_manifest(root, incidents=None):
    return {
        "schema_version": S.STATE_SCHEMA,
        "layout_version": STATE_LAYOUT_VERSION,
        "package_version": S.PACKAGE_VERSION,
        "created": _now(),
        "state_root": str(root),
        "single_sources": {
            "tech_spec": str(P.references_dir() / "tech_spec.json"),
            "redlines": str(P.references_dir() / "redlines.json"),
            "failure_modes": str(P.references_dir() / "failure-modes.json"),
            "strategies_events": str(P.strategies_jsonl(root)),
            "runs": str(P.runs_jsonl(root)),
            "trace": str(P.trace_dir(root)),
        },
        "derived_views": {
            "tech_spec_md": str(P.references_dir() / "TECH_SPEC.md"),
            "strategy_index": str(P.strategy_index_md(root)),
            "note": "派生视图只能由生成脚本写入，禁止手改；一致性由 consistency_check.py 校验"
        },
        "capability": (incidents if incidents is not None else []),
        "pending_backfill": S.PENDING_BACKFILL,
    }


def ensure_initialized(root, run_id=None, with_seeds=True):
    """幂等初始化。返回 {"created":[...], "manifest":..., "seeds_installed":n, "incidents":[...]}"""
    root_s = str(root)
    created_dirs = P.ensure_layout(root)

    prob = env.probe(root_s)
    incidents = prob["incidents"]

    manifest_path = P.state_json(root)
    migrated = None
    manifest = build_manifest(root_s, incidents)
    if manifest_path.exists():
        old, inc = jsonio.safe_read_json(manifest_path, default=None,
                                         quarantine_dir=P.quarantine_dir(root_s))
        if inc is not None:
            # 状态损坏：隔离 + 重建（TC-24 要求：不崩溃、不静默丢失、记录事件）
            incidents.append({"id": "STATE-CORRUPT-REBUILT", "detail": inc,
                              "level": "recovered"})
            migrated = {"from": "corrupt", "to": S.STATE_SCHEMA}
        elif isinstance(old, dict):
            old_layout = int(old.get("layout_version", 1) or 1)
            if old_layout < STATE_LAYOUT_VERSION:
                jsonio.backup_copy(manifest_path)
                migrated = {"from_layout": old_layout, "to_layout": STATE_LAYOUT_VERSION}
            # 保留首次创建时间
            manifest["created"] = old.get("created", manifest["created"])

    jsonio.atomic_write_json(manifest_path, manifest, backup=True)

    seeds_installed = 0
    view = None
    if with_seeds:
        seeds_installed = _strategy.install_seeds(root_s)
        view = _strategy.sync(root_s)

    # runs.jsonl 存在即不被覆盖（加装 touch）
    runs = P.runs_jsonl(root_s)
    if not runs.exists():
        jsonio.atomic_write_text(runs, "")

    return {"created_dirs": created_dirs, "manifest": manifest, "migrated": migrated,
            "seeds_installed": seeds_installed, "strategy_view": view,
            "incidents": incidents, "state_root": root_s}


def doctor(root):
    root_s = str(root)
    prob = env.probe(root_s)
    checks = []
    must = [("state.json", P.state_json(root_s)), ("runs.jsonl", P.runs_jsonl(root_s)),
            ("strategies.jsonl", P.strategies_jsonl(root_s))]
    for name, p in must:
        checks.append({"item": name, "exists": bool(p.exists()), "path": str(p)})
    for name, p in [("TECH_SPEC.md", P.references_dir() / "TECH_SPEC.md"),
                    ("REDLINES.md", P.references_dir() / "REDLINES.md")]:
        checks.append({"item": name, "exists": bool(p.exists()), "path": str(p)})
    idx = P.strategy_index_md(root_s)
    idx_lines = 0
    if idx.exists():
        idx_lines = jsonio.count_lines(idx)
    return {"state_root": root_s, "capability": prob["caps"], "incidents": prob["incidents"],
            "checks": checks, "strategy_index_lines": idx_lines,
            "index_max_lines": int(S.spec_get("strategy.index_max_lines", None, 100)),
            "pending_backfill": S.PENDING_BACKFILL}


def main(argv=None):
    p = cli.parser_for("init_state", __doc__)
    p.add_argument("mode", nargs="?", default="init",
                   choices=["init", "doctor", "reset"], help="init=初始化/迁移 doctor=体检 reset=清空重建")
    p.add_argument("--confirmed-by", default=None, help="（reset）人工确认人，例如 human:顾全策")
    p.add_argument("--token", default=None, help="（reset）confirm.py 签发的确认令牌")
    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    args = p.parse_args(argv)

    if args.selftest:
        return cli.run_selftest(self_test(), name="init_state")

    root = cli.resolve_state(args)

    if args.mode == "doctor":
        return cli.ok_out(doctor(root), pretty=args.pretty)

    if args.mode == "reset":
        # 不可逆：必须经 FP-20 硬关卡
        import confirm as _confirm
        req = _confirm.request(root, action="清空并重建状态目录",
                               scope=str(root), rollback="无（数据将被清空，请先备份 backups/）",
                               run_id=args.run_id)
        if not args.confirmed_by or not args.token:
            return cli.finalize({"ok": False, "need_confirm": True, "redline": "RL-C01",
                                 "request": req, "exit_code": errors.NEED_CONFIRM},
                                errors.NEED_CONFIRM)
        verdict = _confirm.verify(root, req["id"], args.token)
        if not verdict.get("ok"):
            return cli.finalize({"ok": False, "reason": "invalid_token",
                                 "exit_code": errors.NEED_CONFIRM}, errors.NEED_CONFIRM)
        import shutil
        shutil.rmtree(str(root), ignore_errors=True)
        res = ensure_initialized(root, run_id=args.run_id)
        res["reset"] = True
        res["confirmed_by"] = args.confirmed_by
        return cli.ok_out(res, pretty=args.pretty)

    res = ensure_initialized(root, run_id=args.run_id)
    # init 本身也要留痕：Trace 是唯一能证明「这次跑过了」的东西
    tr = TR.Tracer(str(root), args.run_id or TR.new_run_id(), stage="init")
    tr.emit("ensure_initialized", metrics={"dirs_created": len(res["created_dirs"]),
                                           "seeds_installed": res["seeds_installed"]},
            decision={"why": "state bootstrap", "state_root": str(root)})
    for inc in res["incidents"]:
        tr.emit("capability_probe", status="degraded",
                decision={"degraded": True, "why": inc.get("id")}, extra={"incident": inc})
    res["run_id"] = tr.run_id
    return cli.ok_out(res, pretty=args.pretty)


def self_test():
    checks = []
    import tempfile

    def chk(name, cond):
        checks.append((name, bool(cond)))

    with tempfile.TemporaryDirectory() as td:
        root = P.Path(td) / "ce"
        r1 = ensure_initialized(root)
        chk("首次初始化创建 state.json", P.state_json(str(root)).exists())
        chk("初始化安装了 ≥12 条种子", r1["seeds_installed"] >= 12)
        chk("初始化生成 INDEX.md", P.strategy_index_md(str(root)).exists())
        r2 = ensure_initialized(root)
        chk("重复初始化幂等（不再装种子）", r2["seeds_installed"] == 0)
        chk("manifest 含单一事实源清单", len(r2["manifest"]["single_sources"]) >= 5)
        # 损坏自愈
        P.state_json(str(root)).write_text("{broken json", encoding="utf-8")
        r3 = ensure_initialized(root)
        chk("状态损坏后自动隔离并重建", P.state_json(str(root)).exists()
            and any(i.get("id") == "STATE-CORRUPT-REBUILT" for i in r3["incidents"]))
        doc = doctor(root)
        chk("doctor 返回 pending_backfill", len(doc["pending_backfill"]) == 3)
        chk("doctor 返回能力字段", "capability" in doc)
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "init_state"))
