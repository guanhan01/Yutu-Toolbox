# -*- coding: utf-8 -*-
"""FP-20 不可逆动作确认关卡（硬关卡实现）。

设计：**缺省拒绝**。任何不可逆动作必须先 `request` 生成待确认提案（含动作/影响范围/回滚方式），
拿到人类显式确认后，调用方用 `--confirmed-by` + 一次性 token 才能放行。缺任一项 -> 退出码 3，不执行。

为什么这样设计：技能无法在运行期弹窗，唯一可靠的方式是把「待确认状态」落到文件，
由宿主/人类在命令行显式回填确认。忘记确认 = 不执行（而非「我认为你同意了」）。

用法：
  ce confirm request --action "删除 X" --scope "..." --rollback "..."      # 退出码 3
  ce confirm apply   --id <rid> --token <t> --confirmed-by "human:xxx"     # 放行
  ce confirm list
  ce confirm expire  --hours 24        # 清理过期提案（可安全执行）
"""

import datetime
import re
import secrets
import sys

from _lib import cli, errors, jsonio, paths as P

TOKEN_HEX = 8

_ID_WHITELIST = re.compile(r"^[A-Za-z0-9._-]+$")


def _validate_rid(rid):
    """拒绝绝对路径、'..' 穿越、空白与非法字符，避免越界读写状态目录之外文件（P0-5）。"""
    if not rid:
        return False, "empty_id"
    if not _ID_WHITELIST.match(rid):
        return False, "illegal_characters"
    if rid.startswith("/") or rid.startswith("\\") or (".." in rid.split("/")) or ("\\" in rid):
        return False, "path_escape"
    return True, "ok"


def _now():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _age_hours(ts):
    try:
        t = datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
        return (datetime.datetime.utcnow() - t).total_seconds() / 3600.0
    except Exception:
        return 0.0


def request(root, action, scope, rollback, run_id=None, ttl_hours=24):
    """生成待确认提案。**不执行动作**，返回提案 dict（含一次性 token）。"""
    d = P.pending_dir(root)
    P.ensure_dir(d)
    token = secrets.token_hex(TOKEN_HEX)
    rid = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S") + "-" + token[:6]
    payload = {
        "schema_version": "confirm.v1",
        "id": rid,
        "action": action,
        "scope": scope,
        "rollback": rollback,
        "token": token,
        "created": _now(),
        "ttl_hours": ttl_hours,
        "run_id": run_id,
        "state": "pending",
    }
    p = d / ("%s.json" % rid)
    jsonio.atomic_write_json(p, payload)
    payload["request_file"] = str(p)
    payload["how_to_confirm"] = (
        "请由人类确认后执行：ce confirm apply --id %s --token %s --confirmed-by \"human:<姓名>\"" %
        (rid, token))
    return payload


def verify(root, rid, token):
    """校验提案与令牌；同时校验 rid 合法性与路径逃逸。返回 {"ok":bool,...}"""
    ok, why = _validate_rid(rid)
    if not ok:
        return {"ok": False, "reason": "invalid_id", "detail": why, "id": rid}
    f = P.pending_dir(root) / ("%s.json" % rid)
    # 路径逃逸二次断言：归一化后必须仍在 pending_dir 之下
    f = f.resolve()
    base = P.pending_dir(root).resolve()
    if f != base and base not in f.parents:
        return {"ok": False, "reason": "invalid_id", "detail": "escape", "id": rid}
    if not f.exists():
        return {"ok": False, "reason": "request_not_found", "id": rid}
    try:
        obj = jsonio.read_json(f)
    except Exception as exc:
        return {"ok": False, "reason": "request_unreadable", "error": str(exc)}
    if obj.get("token") != token:
        return {"ok": False, "reason": "bad_token", "id": rid}
    if _age_hours(obj.get("created", "")) > float(obj.get("ttl_hours", 24)):
        return {"ok": False, "reason": "expired", "id": rid}
    return {"ok": True, "request": obj, "id": rid}


def apply(root, rid, token, confirmed_by):
    """消费提案：校验通过后把提案标记为 confirmed（由调用方据此执行动作）。

    硬关卡（P0-4/P0-5）：confirmed_by 必须以 human: 开头且不得含 model——禁止模型
    伪造一次「人工确认」。越界 id 已由 verify() 拒绝。
    """
    v = verify(root, rid, token)
    if not v.get("ok"):
        return v
    if not confirmed_by or "model" in str(confirmed_by).lower() or not str(confirmed_by).startswith("human:"):
        return {"ok": False, "reason": "invalid_confirmed_by",
                "detail": "confirmed_by 必须以 human: 开头且不得含 model（禁止模型自批）",
                "exit_code": errors.NEED_CONFIRM}
    f = P.pending_dir(root) / ("%s.json" % rid)
    obj = jsonio.read_json(f)
    obj["state"] = "confirmed"
    obj["confirmed_by"] = confirmed_by
    obj["confirmed_at"] = _now()
    jsonio.atomic_write_json(f, obj)
    return {"ok": True, "id": rid, "confirmed_by": confirmed_by, "action": obj.get("action")}


def list_requests(root, only_pending=True):
    d = P.pending_dir(root)
    if not d.exists():
        return []
    out = []
    for f in sorted(d.glob("*.json")):
        try:
            obj = jsonio.read_json(f)
        except Exception:
            continue
        if only_pending and obj.get("state") not in (None, "pending"):
            continue
        out.append({"id": obj.get("id"), "action": obj.get("action"),
                    "state": obj.get("state", "pending"),
                    "age_hours": round(_age_hours(obj.get("created", "")), 2),
                    "file": str(f)})
    return out


def prune(root, hours=24):
    """清理过期提案（安全动作，不需确认）。"""
    removed = []
    for f in sorted(P.pending_dir(root).glob("*.json")) if P.pending_dir(root).exists() else []:
        try:
            obj = jsonio.read_json(f)
        except Exception:
            continue
        if _age_hours(obj.get("created", "")) > float(obj.get("ttl_hours", hours)):
            f.unlink()
            removed.append(str(f))
    return {"removed": removed, "count": len(removed)}


def main(argv=None):
    p = cli.parser_for("confirm", __doc__)
    p.add_argument("mode", choices=["request", "apply", "list", "prune"])
    p.add_argument("--action", default=None)
    p.add_argument("--scope", default=None)
    p.add_argument("--rollback", default=None)
    p.add_argument("--id", default=None)
    p.add_argument("--token", default=None)
    p.add_argument("--confirmed-by", default=None)
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--selftest", action="store_true")
    _argv = list(argv) if argv is not None else sys.argv[1:]
    if "--selftest" in _argv:
        return cli.run_selftest(self_test(), name="confirm")
    args = p.parse_args(argv)

    if args.selftest:
        return cli.run_selftest(self_test(), name="confirm")

    root = cli.resolve_state(args)

    if args.mode == "request":
        if not args.action or not args.scope or not args.rollback:
            return cli.err_out("request 必须提供 --action / --scope / --rollback（缺一即无法构成有效确认）",
                               errors.USAGE)
        req = request(root, args.action, args.scope, args.rollback, run_id=args.run_id)
        payload = {"ok": False, "need_confirm": True, "redline": "RL-C01",
                   "request": req, "exit_code": errors.NEED_CONFIRM}
        return cli.finalize(payload, errors.NEED_CONFIRM)

    if args.mode == "apply":
        if not args.id or not args.token or not args.confirmed_by:
            return cli.err_out("apply 必须提供 --id / --token / --confirmed-by；"
                               "缺少人工确认时不执行任何不可逆动作", errors.NEED_CONFIRM)
        res = apply(root, args.id, args.token, args.confirmed_by)
        if not res.get("ok"):
            res["exit_code"] = errors.NEED_CONFIRM
            return cli.finalize(res, errors.NEED_CONFIRM)
        res["exit_code"] = errors.OK
        return cli.ok_out(res, pretty=args.pretty)

    if args.mode == "list":
        return cli.ok_out({"requests": list_requests(root, only_pending=False)}, pretty=args.pretty)

    if args.mode == "prune":
        return cli.ok_out(prune(root, args.hours), pretty=args.pretty)

    return cli.err_out("unknown mode", errors.USAGE)


def self_test():
    checks = []
    import tempfile

    def chk(name, cond):
        checks.append((name, bool(cond)))

    with tempfile.TemporaryDirectory() as td:
        req = request(td, action="删除缓存", scope="cache/ 全部条目", rollback="无")
        chk("request 生成 token", len(req["token"]) == TOKEN_HEX * 2)
        chk("request 给出 human 指令", "how_to_confirm" in req)
        chk("未确认前 verify 通过但状态 pending", verify(td, req["id"], req["token"])["ok"] is True)
        bad = apply(td, req["id"], "wrong-token-xxxx", "human:tester")
        chk("错误令牌被拒", bad.get("ok") is False and bad.get("reason") == "bad_token")
        chk("被拒后提案仍 pending", list_requests(td, only_pending=True)[0]["state"] == "pending")
        good = apply(td, req["id"], req["token"], "human:tester")
        chk("正确令牌+确认人放行", good.get("ok") is True)
        chk("放行后提案转 confirmed",
            [r for r in list_requests(td, only_pending=False)
             if r["id"] == req["id"]][0]["state"] == "confirmed")
        old = request(td, action="旧提案", scope="x", rollback="y", ttl_hours=1)
        # 把 created 回拨 48 小时以模拟过期（不改 TTL 判定逻辑本身）
        old_file = P.pending_dir(td) / ("%s.json" % old["id"])
        obj = jsonio.read_json(old_file)
        obj["created"] = ((datetime.datetime.utcnow() - datetime.timedelta(hours=48))
                          .replace(microsecond=0).isoformat() + "Z")
        jsonio.atomic_write_json(old_file, obj)
        chk("过期提案被拒绝", apply(td, old["id"], old["token"], "human:t").get("reason") == "expired")
        chk("prune 清理过期提案", prune(td, hours=1)["count"] >= 1)
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "confirm"))
