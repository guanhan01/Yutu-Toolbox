# -*- coding: utf-8 -*-
"""所有脚本共享的 CLI 骨架：统一输出格式、退出码处理、自测入口。

统一约定（跨平台稳定性来自这里）：
- stdout 永远是**一行 JSON**（唯一跨宿主稳定通道；stderr 可能被丢弃）；
- 人类可读文本（报告/模板输出）通过 `--format md|text` 显式切换，不混在 JSON 里；
- 任何异常都必须变成带 exit_code 的 JSON，不允许抛栈给宿主（异常不允许静默，也不允许糊墙）；
- `--selftest` 使用内嵌 fixture，无需外部文件，保证任何目录/Windows 下都可跑。
"""

import argparse
import json
import sys
import traceback

from . import errors as _errors
from . import paths as _paths


def out(obj, pretty=False):
    text = json.dumps(obj, ensure_ascii=False, indent=2 if pretty else None,
                      sort_keys=False)
    sys.stdout.write(text + "\n")
    sys.stdout.flush()


def err_out(message, exit_code=None, **detail):
    payload = {"ok": False, "error": {"message": message}, "exit_code":
               exit_code if exit_code is not None else _errors.UNEXPECTED}
    if detail:
        payload["error"]["detail"] = detail
    return finalize(payload, exit_code if exit_code is not None else _errors.UNEXPECTED)


def finalize(payload, exit_code=0):
    out(payload)
    return exit_code


def ok_out(payload, exit_code=0, pretty=False):
    if isinstance(payload, dict):
        payload.setdefault("ok", True)
    out(payload, pretty=pretty)
    return exit_code


def add_common(parser, with_run_id=True, with_state=True):
    if with_state:
        parser.add_argument("--state-root", default=None,
                            help="状态根目录（默认：$COGNITIVE_ENGINE_HOME 或 ~/.cognitive-engine）")
    if with_run_id:
        parser.add_argument("--run-id", default=None, help="本次任务 run_id（用于 Trace 关联）")
    parser.add_argument("--pretty", action="store_true", help="JSON 缩进输出")
    return parser


EXIT_NOTE = """退出码: 0=OK 1=内部错误 2=用法错误 3=待人工确认 4=预算熔断 \
5=命中Critical红线 6=命中Standard红线 7=状态已自愈 10=判定不触发 11=质量未达标"""


def parser_for(name, description, with_run_id=True, with_state=True):
    p = argparse.ArgumentParser(
        prog="ce %s" % name,
        description=description,
        epilog=EXIT_NOTE,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    add_common(p, with_run_id=with_run_id, with_state=with_state)
    return p


def print_exitcodes(name="ce"):
    sys.stdout.write(EXIT_NOTE + "\n")


def run_selftest(checks, name="selftest"):
    """checks: [(desc, passed)] -> 打印结果并返回退出码。"""
    failed = [d for d, ok in checks if not ok]
    lines = ["[%s] %d checks, %d passed, %d failed" % (name, len(checks),
                                                       len(checks) - len(failed), len(failed))]
    for desc, okflag in checks:
        lines.append("  [%s] %s" % ("PASS" if okflag else "FAIL", desc))
    sys.stdout.write("\n".join(lines) + "\n")
    return 0 if not failed else 1


def safe_dispatch(main_fn, argv=None, name="script"):
    """包一层统一异常 -> JSON + 退出码（公理Ⅲ：异常不得静默吞掉）。"""
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        code = main_fn(argv)
        if code is None:
            code = 0
        return int(code)
    except _errors.CEError as exc:
        return err_out(exc.message, exc.exit_code, **exc.detail)
    except KeyboardInterrupt:
        return err_out("interrupted", _errors.UNEXPECTED)
    except SystemExit:
        raise
    except Exception as exc:  # 明确报错，不吞异常
        detail = {"type": type(exc).__name__, "traceback": traceback.format_exc(limit=4)}
        return err_out(str(exc), _errors.UNEXPECTED, **detail)


def resolve_state(args):
    """把 --state-root 解析成 Path（未指定走 paths.state_root()）。"""
    return _paths.state_root(getattr(args, "state_root", None))


# ---------------- 全局参数的位置无关化 ----------------
#
# argparse 的默认行为：挂在父 parser 上的 --pretty / --state-root / --run-id
# **只在子命令之前**才被识别，写在子命令后面会报 unrecognized arguments。
# 这对 Windows 命令行用户是隐性坑（他们不会读 argparse 文档），所以这里统一处理：
# 先把任意位置的全局参数抽出来，解析剩余的，再回填到 namespace。

GLOBAL_FLAGS = ("--pretty", "--selftest")
GLOBAL_OPTS = ("--state-root", "--run-id")


def split_globals(argv):
    """返回 (globals_dict, rest_argv)。globals_dict 形如 {'pretty': True, 'run_id': 'x'}。"""
    argv = list(argv if argv is not None else sys.argv[1:])
    global_map, rest = {}, []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in GLOBAL_FLAGS:
            global_map[a.lstrip("-").replace("-", "_")] = True
        elif a in GLOBAL_OPTS and (i + 1) < len(argv):
            global_map[a.lstrip("-").replace("-", "_")] = argv[i + 1]
            i += 1
        else:
            rest.append(a)
        i += 1
    return global_map, rest


def parse_with_globals(parser, argv=None):
    """等价于 parser.parse_args(argv)，但全局参数写在任何位置都生效。"""
    global_map, rest = split_globals(argv)
    args = parser.parse_args(rest)
    for key, val in global_map.items():
        setattr(args, key, val)
    return args


def maybe_selftest(args, fn):
    """若带 --selftest 则执行自测并退出；否则返回 None 继续正常流程。"""
    if getattr(args, "selftest", False):
        return run_selftest(fn(), name=getattr(args, "prog", "selftest"))
    return None
