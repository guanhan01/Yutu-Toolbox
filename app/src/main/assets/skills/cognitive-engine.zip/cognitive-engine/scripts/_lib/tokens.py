# -*- coding: utf-8 -*-
"""token 估算器（纯标准库、无 tokenizer、无 API 计量）。

设计取舍（详见 PLATFORM_RESEARCH §2.1）：
- 估算值**永远携带 method + confidence**，禁止只输出一个数字；
- 误差主要是「乘性系统偏差」而非随机噪声 => 用于相对排序可靠，用于硬闸门需配合安全系数；
- 每次拿到宿主真实 usage 时可回写校准系数（EMA），校准样本不足时 confidence=low。

估算模型：
    est_raw = Σ_class (chars_class / chars_per_token_class) * alpha_class
    tokens  = ceil(est_raw * safety)
其中 class ∈ {en, code, json, cjk}，cjk 取更小的 chars/token（即更保守、偏高估）。
"""

import math
from pathlib import Path

# 字符分类用的启发式（全部可用标准库实现）
_CODE_KEYWORDS = ("def ", "class ", "import ", "function", "const ", "var ", "let ",
                  "return", "self.", "->", "=>", "#include", "public ", "private ",
                  "SELECT ", "FROM ", "WHERE ")
_CODE_PUNCT = set("{}()[];=<>|&+-*/%!@$")
_JSON_HINT = ('":"', '":', '{"', '[{', '},', ']')
_INDENT_STEP = 4

_CLASS_ORDER = ("en", "code", "json", "cjk")


def _is_cjk(ch):
    """CJK 统一表意文字 + 中文标点 + 日文/韩文常用区 + 全角符号。"""
    o = ord(ch)
    if 0x4E00 <= o <= 0x9FFF:      # CJK 统一表意文字
        return True
    if 0x3400 <= o <= 0x4DBF:      # 扩展 A
        return True
    if 0x3000 <= o <= 0x303F:      # 中文标点
        return True
    if 0xFF00 <= o <= 0xFFEF:      # 全角形式
        return True
    if 0x3040 <= o <= 0x30FF:      # 日文假名
        return True
    if 0xAC00 <= o <= 0xD7AF:      # 韩文音节
        return True
    return False


def classify_lines(text):
    """按行粗分类，返回 {class: 字符数} 与每行的分类（用于调试）。"""
    counts = {c: 0 for c in _CLASS_ORDER}
    lines = text.splitlines()
    for line in lines:
        stripped = line.strip()
        if not stripped:
            counts["en"] += len(line) + 1
            continue
        cjk = sum(1 for ch in line if _is_cjk(ch))
        cjk_ratio = cjk / float(max(1, len(stripped)))
        code_score = 0
        lead = len(line) - len(line.lstrip(" \t"))
        if lead >= _INDENT_STEP:
            code_score += 1
        for kw in _CODE_KEYWORDS:
            if kw in line:
                code_score += 1
                break
        punct = sum(1 for ch in line if ch in _CODE_PUNCT)
        if punct >= 3:
            code_score += 1
        json_score = sum(1 for hint in _JSON_HINT if hint in line.replace(" ", ""))
        n = len(line) + 1
        if cjk_ratio >= 0.3:
            # 中文为主的行：少量 code 记号不改变其 token 密度主导因素
            counts["cjk"] += n
        elif json_score >= 2:
            counts["json"] += n
        elif code_score >= 2:
            counts["code"] += n
        else:
            counts["en"] += n
    return counts


def load_calibration(state_root):
    """读取 calibration.json：{alpha:{class:float}, n_samples:int, updated:str}"""
    import json
    p = Path(state_root) / "calibration.json"
    try:
        with open(str(p), "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        data = {}
    alpha = {c: float(data.get("alpha", {}).get(c, 1.0)) for c in _CLASS_ORDER}
    return {"alpha": alpha,
            "n_samples": int(data.get("n_samples", 0) or 0),
            "updated": data.get("updated")}


def confidence_of(n_samples, min_high):
    return "high" if n_samples >= min_high else "low"


def safety_coefficient(confidence, cjk_ratio=0.0):
    """§11.2.4 R-保守1 的安全系数表。返回 (coefficient, rule_note)。

    取值来源唯一：references/budget-bands.json -> safety_rules["R-保守1"]。
    取不到配置返回 (None, 说明)，由调用方回落到 tech_spec.safety（**不做静默拍值**）。
    """
    rule = None
    try:
        from . import schema as _schema
        rule = (_schema.band_cfg().get("safety_rules") or {}).get("R-保守1")
    except Exception:
        rule = None
    if not isinstance(rule, dict):
        return None, "R-保守1 配置缺失 -> 回落 tech_spec.token_model.safety（降级，须在输出标注）"
    if confidence in ("high", "metered"):
        return float(rule.get("confidence_high_or_metered", 1.0)), "confidence=high/metered -> SAFETY 1.00"
    # 以下是 confidence=low 分支：中英混排是最大不确定性来源，CJK 占比超阈值再抬一档
    cjk_gate = float(rule.get("confidence_low_and_cjk_gt", 0.30))
    if float(cjk_ratio or 0.0) > cjk_gate:
        return float(rule.get("confidence_low_cjk", 1.35)), \
            "confidence=low 且 CJK>%.2f -> SAFETY 1.35（实测 cjk_ratio=%.3f）" % (cjk_gate, cjk_ratio)
    return float(rule.get("confidence_low", 1.15)), \
        "confidence=low -> SAFETY 1.15（cjk_ratio=%.3f）" % float(cjk_ratio or 0.0)


def estimate(text, spec=None, calibration=None, state_root=None):
    """返回估算结果 dict。

    字段：tokens / est_raw / classes / method / confidence / alpha / safety / chars
    """
    from . import schema as _schema
    spec = spec or _schema.spec_get("token_model", None, None) or {}
    cpt = spec.get("chars_per_token", {"en": 4.0, "code": 3.0, "json": 2.6, "cjk": 1.2})
    safety_cfg = spec.get("safety", {"base": 1.15, "low_confidence_extra": 1.15})
    cal_cfg = spec.get("calibration", {"beta": 0.3, "min_samples_high_confidence": 20})

    if calibration is None:
        calibration = (load_calibration(state_root) if state_root
                       else {"alpha": {c: 1.0 for c in _CLASS_ORDER}, "n_samples": 0})
    cal = dict(calibration)  # 统一别名：后续所有读取都走 cal，避免同名不同源
    cal.setdefault("alpha", {c: 1.0 for c in _CLASS_ORDER})
    counts = classify_lines(text)
    est_raw = 0.0
    for c in _CLASS_ORDER:
        k = float(cpt.get(c, 4.0)) or 4.0
        a = float(cal["alpha"].get(c, 1.0))
        est_raw += (counts[c] / k) * a

    conf = confidence_of(int(cal.get("n_samples", 0)),
                         int(cal_cfg.get("min_samples_high_confidence", 20)))
    # §11.2.4 R-保守1：SAFETY 只向上取，优先按保守宽度表取值；无该表时回落 tech_spec
    cjk_ratio = (float(counts.get("cjk", 0)) / float(sum(counts.values()))
                 if sum(counts.values()) else 0.0)
    coefficient, why = safety_coefficient(conf, cjk_ratio)
    safety = coefficient if coefficient else float(safety_cfg.get("base", 1.15))

    est_for_gate = int(math.ceil(est_raw * safety))
    return {
        "tokens": est_for_gate,
        "est_raw": round(est_raw, 3),
        "chars": sum(counts.values()),
        "chars_per_class": counts,
        "classes": counts,
        "cjk_ratio": round(cjk_ratio, 4),
        "safety_rule": why,
        "method": "heuristic.v1",
        "confidence": conf,
        "alpha": {c: round(cal["alpha"].get(c, 1.0), 4) for c in _CLASS_ORDER},
        "safety": round(safety, 3),
        "calibration_samples": int(cal.get("n_samples", 0)),
    }


def estimate_file(path, **kw):
    p = Path(path)
    with open(str(p), "r", encoding="utf-8", errors="replace") as fh:
        return estimate(fh.read(), **kw)


def update_calibration(state_root, text, real_tokens, classes=None):
    """用真实 usage 回写 EMA 校准系数。返回 (calibration, delta_info)。"""
    from . import schema as _schema
    from . import jsonio
    import datetime
    spec = _schema.spec_get("token_model") or {}
    beta = float(spec.get("calibration", {}).get("beta", 0.3))
    min_high = int(spec.get("calibration", {}).get("min_samples_high_confidence", 20))

    counts = classes or classify_lines(text)
    cpt = spec.get("chars_per_token", {"en": 4.0, "code": 3.0, "json": 2.6, "cjk": 1.2})
    est_raw = sum((counts[c] / float(cpt.get(c, 4.0))) for c in _CLASS_ORDER)

    cal = load_calibration(state_root)
    ratio = (float(real_tokens) / est_raw) if est_raw > 0 else 1.0
    for c in _CLASS_ORDER:
        old = float(cal["alpha"].get(c, 1.0))
        cal["alpha"][c] = round(old * (1.0 - beta) + ratio * beta, 5)
    cal["n_samples"] = int(cal["n_samples"]) + 1
    cal["updated"] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    cal["last_ratio"] = round(ratio, 4)

    # §11.2.4 情形 D 需要 |est-real|/real 的 p50，因此这里必须留历史样本（否则冻结判定无从计算）
    drift = abs(float(real_tokens) - est_raw) / est_raw if est_raw > 0 else 0.0
    history = list(cal.get("samples") or [])
    history.append({"real": int(real_tokens), "est_raw": round(est_raw, 2),
                    "ratio": round(ratio, 4), "drift": round(drift, 4), "ts": cal["updated"]})
    cal["samples"] = history[-50:]
    _sorted = sorted(float(h.get("drift", 0.0)) for h in cal["samples"])
    if _sorted:
        k = int(round((len(_sorted) - 1) * 0.5))
        cal["drift_p50"] = round(_sorted[k], 4)

    p = Path(state_root) / "calibration.json"
    jsonio.ensure_parent(p)
    jsonio.atomic_write_json(p, cal)
    cal["confidence"] = confidence_of(cal["n_samples"], min_high)
    return cal, {"ratio": round(ratio, 4), "drift_pct": round((ratio - 1.0) * 100.0, 2)}


def self_test():
    """确定性性质测试：单调性 + 稳定性 + 分类有效性。"""
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    base_text = "hello world, this is a plain english sentence. "
    a = estimate(base_text)
    b = estimate(base_text * 3)
    chk("幂等：同输入同结果", estimate("hello world") == estimate("hello world"))
    chk("单调性：更长文本估算不小于更短", b["tokens"] >= estimate("hello world")["tokens"])
    cjk = estimate("这是一个中文句子，用于验证中文内容的估算是否偏高。" * 3)
    chk("中文按 cjk 类计数", cjk["classes"]["cjk"] > 0)
    code = estimate("def foo(x):\n    return x + 1\n\nimport os\n" * 3)
    chk("代码被识别为 code 类", code["classes"]["code"] > 0)
    js = estimate('{"a": 1, "b": 2, "c": [1,2,3]}\n' * 3)
    chk("JSON 被识别为 json 类", js["classes"]["json"] > 0)
    chk("估算结果带 confidence 字段", "confidence" in a and a["confidence"] in ("high", "low"))
    chk("估算结果带 method 字段", a["method"] == "heuristic.v1")
    return checks
