# -*- coding: utf-8 -*-
"""FP-07 覆盖度矩阵与缺口对账（主链路第 5 节点的确定性闸门）。

覆盖度是「这次有没有漏掉该答的」的度量。它由脚本产出而**不是模型自述**，因为：
- gold 项（需求/约束/接口/边界）是外部给定的清单；
- 「某段结论是否覆盖了某条 gold」是可用相似度判定的确定问题；
- 最关键的是判 `silently_swallowed`（声称覆盖但实际没匹上）—— 这是只能靠脚本抓的自欺行为。

失败判据对齐 PRD §11.1.3：
    F4  coverage < 70%  或  存在被静默吞掉的未覆盖项（声明覆盖了但证据对不上）
中间态 partial：coverage ∈ [70%, 90%)

用法：
  ce coverage check --gold <gold.json> --conclusion <conclusion.json|text> [--round 1]
  ce coverage check --gold gold.json --conclusion out.md --format md
"""

from _lib import cli, errors, jsonio, schema as S
from _lib import sim

MAX_BACKFILL_ROUNDS = 2


def load_items(path, keys=("items", "requirements", "gold")):
    """读入清单。支持 JSON array / JSON object（取第一个命中的 key）/ 纯文本（按行切）。"""
    text = jsonio.read_text(path).strip()
    if not text:
        return []
    if text[0] in "[":
        rows = jsonio.read_json(path)
    elif text[0] in "{":
        obj = jsonio.read_json(path)
        rows = None
        for k in keys:
            if isinstance(obj.get(k), list):
                rows = obj[k]
                break
        rows = rows or []
    else:
        rows = [{"text": line} for line in text.splitlines() if line.strip()]
    out = []
    for i, row in enumerate(rows):
        if isinstance(row, str):
            row = {"text": row}
        row = dict(row)
        row.setdefault("id", "g%d" % (i + 1))
        out.append(row)
    return out


def chunk_conclusion(text):
    """把结论切成可比对片段。确定性：空行分段 -> 句子再切（中英文标点均支持）。"""
    chunks = []
    import re
    for para in re.split(r"\n\s*\n", text or ""):
        para = para.strip()
        if not para:
            continue
        parts = re.split(r"(?<=[。！？；.!?;])\s*", para)
        for p in parts:
            p = p.strip()
            if p:
                chunks.append(p)
    return chunks


def coverage_score(gold_text, concl_text, idf=None):
    """覆盖度专用匹配分 = max(char_3gram_jaccard, tfidf_cosine, gold_term_containment)。

    为什么要第三个度量：前两个是**对称**相似度，而「某段结论是否覆盖了这条 gold」是
    **非对称**问题——gold 很短、结论很长时，对称相似度会被结论的独有内容稀释
    （实测用例：gold「超卖场景需要乐观锁或库存预扣」vs 结论句 -> jaccard 0.263、
    cosine 0.212，均低于 0.35 阈值，但显然已覆盖）。

    gold_term_containment = |terms(gold) ∩ terms(concl)| / |terms(gold)|
    （terms 为中文 2-gram + ASCII 词，天然抑制单个虚词带来的假阳性）

    本机样本判别间隔：正例 0.385 ~ 1.0，负例 0.0；阈值沿用 tech_spec.coverage.match_threshold。
    """
    a_terms = set(sim.word_tokens(gold_text))
    b_terms = set(sim.word_tokens(concl_text or ""))
    containment = (len(a_terms & b_terms) / float(len(a_terms))) if a_terms else 0.0
    j = sim.jaccard_3gram(gold_text, concl_text or "")
    idf = idf if idf is not None else sim.build_idf([gold_text, concl_text or ""])
    c = sim.cosine(sim.tfidf_vector(gold_text, idf), sim.tfidf_vector(concl_text or "", idf))
    score = max(containment, j, c)
    metric = ("term_containment" if score == containment
              else ("jaccard_3gram" if score == j else "tfidf_cosine"))
    return {"similarity": round(score, 4), "term_containment": round(containment, 4),
            "jaccard_3gram": round(j, 4), "tfidf_cosine": round(c, 4), "metric": metric}


def check_coverage(gold, conclusion_text=None, conclusion_items=None, round_no=0,
                   target_rate=None, match_threshold=None):
    """核心比对。返回 dict（含 matrix / coverage_rate / problems / exit_code）。"""
    cfg = S.spec_get("coverage") or {}
    target = float(target_rate if target_rate is not None
                   else cfg.get("target_rate", 0.9) or 0.9)
    match_th = float(match_threshold if match_threshold is not None
                     else cfg.get("match_threshold", 0.35) or 0.35)
    max_rounds = int(cfg.get("max_backfill_rounds", MAX_BACKFILL_ROUNDS) or MAX_BACKFILL_ROUNDS)

    if conclusion_items is None:
        conclusion_items = [{"id": "s%d" % (i + 1), "text": t}
                            for i, t in enumerate(chunk_conclusion(conclusion_text))]
    c_texts = [str(c.get("text", "")) for c in conclusion_items]
    idf = sim.build_idf([str(g.get("text", "")) for g in gold] + c_texts)

    matrix, covered = [], 0
    for g in gold:
        gtext = str(g.get("text", ""))
        best = {"conclusion_id": None, "similarity": 0.0, "metric": None}
        for c in conclusion_items:
            d = coverage_score(gtext, str(c.get("text", "")), idf)
            if d["similarity"] > best["similarity"]:
                best = {"conclusion_id": c.get("id"), "similarity": d["similarity"],
                        "metric": d["metric"]}
        declared = bool(g.get("covered", False))
        matched = best["similarity"] >= match_th
        explicitly = [x for x in (g.get("covered_by") or [])]
        is_covered = bool(matched or declared or explicitly)
        if is_covered:
            covered += 1
        row = {"gold_id": g.get("id"), "text": gtext[:80], "covered": is_covered,
               "declared": declared, "matched": matched,
               "covered_by": explicitly,
               "best_match": best, "critical": bool(g.get("critical"))}
        if declared and not matched and not explicitly:
            row["silently_swallowed"] = True
        matrix.append(row)

    total = len(gold) or 1
    rate = round(covered / float(total), 4)
    uncovered = [r["gold_id"] for r in matrix if not r["covered"]]
    swallowed = [r["gold_id"] for r in matrix if r.get("silently_swallowed")]
    critical_missing = [r["gold_id"] for r in matrix if r["critical"] and not r["covered"]]

    failure = []
    verdict = "ok"
    if rate < 0.70 or swallowed:
        failure.append("F4")
        verdict = "failed"
    elif rate < target:
        verdict = "partial"

    can_backfill = (verdict in ("partial", "failed")) and int(round_no or 0) < max_rounds
    res = {
        "total_gold": len(gold), "covered": covered, "coverage_rate": rate,
        "target_rate": target, "match_threshold": match_th,
        "uncovered": uncovered, "silently_swallowed": swallowed,
        "critical_missing": critical_missing,
        "round": int(round_no or 0), "max_backfill_rounds": max_rounds,
        "can_backfill": can_backfill,
        "verdict": verdict, "failure_criteria": failure,
        "matrix": matrix,
        "conclusion_chunks": len(conclusion_items),
    }
    if verdict == "failed":
        res["exit_code"] = errors.QUALITY_UNMET
        res["reason"] = ("覆盖率 %.0f%% < 70%% 或存在 %d 条被静默吞掉的未覆盖项（F4）"
                         % (rate * 100, len(swallowed)))
    elif verdict == "partial":
        res["exit_code"] = errors.QUALITY_UNMET
        res["reason"] = ("覆盖率 %.0f%% 未达 %.0f%%：%s" % (
            rate * 100, target * 100,
            ("可再回填 %d 轮" % (max_rounds - int(round_no or 0))) if can_backfill
            else "回填轮次已用尽，必须在输出中显式列出未覆盖项"))
    else:
        res["exit_code"] = errors.OK
        res["reason"] = "覆盖率 %.0f%% ≥ %.0f%%" % (rate * 100, target * 100)
    return res


def render_md(res):
    lines = ["# 覆盖度矩阵", "",
             "- gold 项：%d，已覆盖：%d，覆盖率：%.0f%%（目标 %.0f%%）"
             % (res["total_gold"], res["covered"], res["coverage_rate"] * 100,
                res["target_rate"] * 100),
             "- 判定：%s；未覆盖：%s" % (res["verdict"], ",".join(res["uncovered"]) or "无")]
    if res["silently_swallowed"]:
        lines.append("- **被静默吞掉的项**：%s（声称覆盖但对不上证据）"
                     % ",".join(res["silently_swallowed"]))
    lines += ["", "| gold | 覆盖 | 相似度 | 最佳匹配 | 备注 |", "|---|---|---|---|---|"]
    for r in res["matrix"]:
        note = "静默吞掉" if r.get("silently_swallowed") else ("关键缺失" if r["critical"]
                                                          and not r["covered"] else "")
        lines.append("| %s | %s | %.2f | %s | %s |" % (
            r["gold_id"], "是" if r["covered"] else "否", r["best_match"]["similarity"],
            r["best_match"]["conclusion_id"] or "-", note))
    return "\n".join(lines) + "\n"


def main(argv=None):
    import sys
    p = cli.parser_for("coverage", __doc__)
    p.add_argument("mode", nargs="?", default="check", choices=["check"])
    p.add_argument("--gold", required=True, help="gold 清单 JSON：{'items':[{'id','text','critical'}]}")
    p.add_argument("--conclusion", required=True, help="结论 JSON 或纯文本")
    p.add_argument("--round", type=int, default=0, help="当前回填轮次（≤2）")
    p.add_argument("--target-rate", type=float, default=None)
    p.add_argument("--match-threshold", type=float, default=None)
    p.add_argument("--format", default="json", choices=["json", "md"])
    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    # 先于必填参数处理 --selftest：自测必须能在任何目录、不带任何输入的情况下跑通
    if "--selftest" in (argv if argv is not None else sys.argv[1:]):
        return cli.run_selftest(self_test(), name="coverage")
    args = cli.parse_with_globals(p, argv)

    gold = load_items(args.gold)
    items = None
    text = None
    raw = jsonio.read_text(args.conclusion).strip()
    if raw[:1] in "[{":
        items = load_items(args.conclusion)
    else:
        text = raw
    res = check_coverage(gold, conclusion_text=text, conclusion_items=items,
                         round_no=args.round, target_rate=args.target_rate,
                         match_threshold=args.match_threshold)
    res["ok"] = res["exit_code"] == errors.OK
    if args.format == "md":
        import sys
        sys.stdout.write(render_md(res))
        return res["exit_code"]
    return cli.finalize(res, res["exit_code"])


def self_test():
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    gold = [{"id": "g1", "text": "订单幂等键必须全局唯一", "critical": True},
            {"id": "g2", "text": "超卖场景需要乐观锁或库存预扣", "critical": True},
            {"id": "g3", "text": "失败重试需要退避策略"},
            {"id": "g4", "text": "需要对账脚本校验最终一致性"}]
    good = "\n".join(["订单幂等键必须全局唯一，采用雪花 ID。",
                      "超卖场景用乐观锁 version 字段控制。",
                      "失败重试采用指数退避并有最大次数。",
                      "提供对账脚本按日校验最终一致性。"])
    res = check_coverage(gold, conclusion_text=good)
    chk("全覆盖时 verdict=ok", res["verdict"] == "ok" and res["exit_code"] == errors.OK)
    chk("覆盖率全额计算", res["coverage_rate"] == 1.0)

    part = "\n".join(["订单幂等键必须全局唯一，采用雪花 ID。",
                      "超卖场景用乐观锁 version 字段控制。",
                      "失败重试采用指数退避。"])
    pres = check_coverage(gold, conclusion_text=part)
    chk("缺一条时判 partial", pres["verdict"] == "partial" and
        pres["exit_code"] == errors.QUALITY_UNMET)
    chk("未覆盖项被显式列出", pres["uncovered"] == ["g4"])
    chk("第一轮允许回填", pres["can_backfill"] is True)
    chk("轮次用尽后不再允许回填",
        check_coverage(gold, conclusion_text=part, round_no=2)["can_backfill"] is False)

    bad = "订单幂等键这块我们处理过了，别的不重要。"
    bres = check_coverage(gold, conclusion_text=bad)
    chk("低于 70% 直接判 failed(F4)", bres["verdict"] == "failed" and "F4" in bres["failure_criteria"])

    declared = [{"id": "g1", "text": "订单幂等键必须全局唯一", "covered": True}]
    dres = check_coverage(declared, conclusion_text="今天天气不错。")
    chk("声明覆盖但对不上 = 静默吞掉", dres["silently_swallowed"] == ["g1"])
    chk("存在静默吞掉即失败", dres["verdict"] == "failed")

    cres = check_coverage([{"id": "g1", "text": "必须灰度发布", "critical": True}],
                          conclusion_text="完全没有提灰度。")
    chk("关键项缺失被标记", cres["critical_missing"] == ["g1"])

    chk("空 gold 不崩溃", check_coverage([], conclusion_text="x")["total_gold"] == 0)
    chk("md 渲染含表头", "| gold |" in render_md(res))
    chk("结论为空时覆盖率 0", check_coverage(gold, conclusion_text="")["coverage_rate"] == 0.0)
    chk("结果确定性", check_coverage(gold, conclusion_text=part)["matrix"] ==
        check_coverage(gold, conclusion_text=part)["matrix"])
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "coverage"))
