# -*- coding: utf-8 -*-
"""FP-06/FP-08 证据绑定校验与置信度分级（红线 RL-C04 的具体检查动作）。

三条铁律在这里被执行：
1. 每条结论断言必须挂 evidence（file:line / 命令输出 / 显式 unverified）；
2. type=file 的证据**必须真的存在且行号不越界**——伪造证据命中 🔴 RL-C04；
3. 无源断言不准进结论区—— evidenced_ratio 未达阈值即判 QUALITY_UNMET。

置信度分级（tech_spec.claims.confidence_rules）：
    high    = 有直接证据（file 命中且过反证检查）
    medium  = 仅有间接证据（命令输出 / 未做反证检查的文件行）
    low     = 只有推理、无证据（unverified）

用法：
  ce claims verify --claims <claims.json> [--root <代码根>]
  claims.json：[{"id":"c1","text":"...","evidence":{"type":"file","ref":"src/a.py","lines":[10,20]}}]
"""

from pathlib import Path

from _lib import cli, errors, jsonio, schema as S

EVIDENCE_FILE = "file"
EVIDENCE_CMD = "cmd"
EVIDENCE_UNVERIFIED = "unverified"


def load_claims(path=None, items=None):
    if items is not None:
        rows = list(items)
    else:
        obj = jsonio.read_json(path)
        rows = obj.get("claims") if isinstance(obj, dict) else obj
    out = []
    for i, row in enumerate(rows or []):
        row = dict(row)
        row.setdefault("id", "claim%d" % (i + 1))
        out.append(row)
    return out


def _file_line_count(path):
    try:
        with open(str(path), "r", encoding="utf-8", errors="replace") as fh:
            n = 0
            for _ in fh:
                n += 1
            return n
    except Exception:
        return None


def check_one(claim, root=None):
    """校验单条 claim。返回 {"id","status","confidence","problem","source"}。"""
    base = Path(root) if root else Path.cwd()
    ev = claim.get("evidence") or {}
    etype = ev.get("type", EVIDENCE_UNVERIFIED)
    out = {"id": claim.get("id"), "claim": str(claim.get("text", ""))[:120],
           "evidence_type": etype, "status": "unverified", "confidence": "low",
           "problem": None}
    if not ev:
        # RL-C04 detect 规则明文包含「claim 无 evidence 字段」：此时唯一正当处置是
        # 补标 unverified **或** 把它移出结论区——两者都要求本次调用先停下来，故计为 forged
        out["status"] = "forged"
        out["problem"] = {"code": "no_evidence", "detail": "claim 缺少 evidence 字段",
                          "redline": "RL-C04"}
        return out

    if etype == EVIDENCE_FILE:
        ref = ev.get("ref")
        target = Path(ref)
        if not target.is_absolute():
            target = base / str(ref)
        exists = target.exists()
        lines = ev.get("lines") or []
        total = _file_line_count(target) if exists else None
        lo = int(lines[0]) if len(lines) > 0 else None
        hi = int(lines[-1]) if len(lines) > 0 else None
        if not exists:
            out["status"] = "forged"
            out["problem"] = {"code": "evidence_file_missing", "ref": str(ref),
                              "resolved": str(target), "redline": "RL-C04"}
            return out
        if total is not None and hi is not None and int(hi) > total:
            out["status"] = "forged"
            out["problem"] = {"code": "evidence_line_out_of_range", "ref": str(ref),
                              "line": int(hi), "file_lines": total, "redline": "RL-C04"}
            return out
        out["status"] = "verified"
        out["file_lines"] = total
        out["lines"] = [lo, hi]
        out["confidence"] = "high" if claim.get("rebuttal_checked") else "medium"
        return out

    if etype == EVIDENCE_CMD:
        stdout = str(ev.get("stdout", "") or "")
        sentinel = ev.get("sentinel")
        if sentinel:
            sp = Path(sentinel)
            if not sp.is_absolute():
                sp = base / str(sentinel)
            if not sp.exists():
                out["status"] = "forged"
                out["problem"] = {"code": "evidence_sentinel_missing", "sentinel": str(sentinel),
                                  "redline": "RL-C04"}
                return out
            out["confidence"] = "high" if claim.get("rebuttal_checked") else "medium"
        elif stdout.strip():
            out["confidence"] = "medium"
        else:
            out["status"] = "forged"
            out["problem"] = {"code": "evidence_cmd_no_output",
                              "detail": "cmd 类证据既无 stdout 也无 sentinel 文件",
                              "redline": "RL-C04"}
            return out
        out["status"] = "verified"
        return out

    if etype == EVIDENCE_UNVERIFIED:
        out["status"] = "unverified"
        out["confidence"] = "low"
        out["note"] = ev.get("note") or "显式标注为未验证，允许保留但不得与已验证断言同权"
        return out

    out["status"] = "forged"
    out["problem"] = {"code": "unknown_evidence_type", "type": etype, "redline": "RL-C04"}
    return out


def verify(claims, root=None, min_evidenced_ratio=None):
    """批量校验。返回 dict（含 redline RL-C04 命中情况与质量结论）。"""
    cfg = S.spec_get("claims") or {}
    min_ratio = float(cfg.get("min_evidenced_ratio", 0.7) if min_evidenced_ratio is None
                      else min_evidenced_ratio)
    rows = [check_one(c, root) for c in claims]
    total = len(rows) or 1
    verified = [r for r in rows if r["status"] == "verified"]
    forged = [r for r in rows if r["status"] == "forged"]
    unverified = [r for r in rows if r["status"] == "unverified"]
    ratio = round(len(verified) / float(total), 4)
    res = {
        "total": len(rows), "verified": len(verified), "unverified": len(unverified),
        "forged": len(forged), "evidenced_ratio": ratio, "min_evidenced_ratio": min_ratio,
        "confidence_mix": {"high": len([r for r in rows if r["confidence"] == "high"]),
                           "medium": len([r for r in rows if r["confidence"] == "medium"]),
                           "low": len([r for r in rows if r["confidence"] == "low"])},
        "rows": rows,
        "redline": None,
    }
    if forged:
        res["redline"] = {"id": "RL-C04", "level": "critical",
                          "must_retract": [r["id"] for r in forged],
                          "recommended": "把这些 claim 降级为 unverified 或移出结论区；"
                                         "证据必须可追溯到真实文件行或真实命令输出",
                          "trigger_action": "claims.py verify --claims <claims.json>"}
        res["verdict"] = "redline"
        res["exit_code"] = errors.REDLINE_CRITICAL
        res["reason"] = "发现 %d 条伪造/失效证据（RL-C04），必须先撤回" % len(forged)
        return res
    if ratio < min_ratio:
        res["verdict"] = "unmet"
        res["exit_code"] = errors.QUALITY_UNMET
        res["reason"] = "证据绑定率 %.0f%% < %.0f%%（缺证不说满）" % (ratio * 100, min_ratio * 100)
        return res
    res["verdict"] = "ok"
    res["exit_code"] = errors.OK
    res["reason"] = "证据绑定率 %.0f%% ≥ %.0f%%，无伪造证据" % (ratio * 100, min_ratio * 100)
    return res


def main(argv=None):
    import sys
    p = cli.parser_for("claims", __doc__)
    p.add_argument("mode", nargs="?", default="verify", choices=["verify"])
    p.add_argument("--claims", required=True, help="claims JSON 文件")
    p.add_argument("--root", default=None, help="file 类证据的根目录（默认当前目录）")
    p.add_argument("--min-evidenced-ratio", type=float, default=None)
    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    # 先于必填参数处理 --selftest（自测不得依赖任何外部输入）
    if "--selftest" in (argv if argv is not None else sys.argv[1:]):
        return cli.run_selftest(self_test(), name="claims")
    args = cli.parse_with_globals(p, argv)
    items = load_claims(args.claims)
    if not items:
        raise errors.CEError("claims 文件为空：没有断言就没有结论", errors.USAGE)
    res = verify(items, args.root, args.min_evidenced_ratio)
    res["ok"] = res["exit_code"] == errors.OK
    return cli.finalize(res, res["exit_code"])


def self_test():
    checks = []
    import tempfile

    def chk(name, cond):
        checks.append((name, bool(cond)))

    tmp = Path(tempfile.mkdtemp(prefix="ce-claims-"))
    src = tmp / "a.py"
    src.write_text("\n".join(["line1", "line2", "line3", "line4", "line5"]), encoding="utf-8")

    # 绑定率门槛 0.7：3 条里 2 条有证据 = 0.667 仍不达标，故这里用 4 条（3 有证据）
    good = [{"id": "c1", "text": "存在第 2 行", "evidence": {"type": "file", "ref": "a.py",
                                                        "lines": [2, 3]},
             "rebuttal_checked": True},
            {"id": "c2", "text": "命令输出表明通过", "evidence": {"type": "cmd",
                                                          "stdout": "5 passed"}},
            {"id": "c3", "text": "长跑任务完成", "evidence": {"type": "cmd",
                                                       "sentinel": "a.py"}},
            {"id": "c4", "text": "这个推断还没验证", "evidence": {"type": "unverified"}}]
    res = verify(good, str(tmp))
    chk("正常组合：三条 verified", res["verified"] == 3 and res["verdict"] == "ok")
    chk("unverified 明确计数", res["unverified"] == 1)
    chk("绑定率按 3/4=0.75 计算", abs(res["evidenced_ratio"] - 0.75) < 1e-6)
    chk("置信度分级 high/medium/low 齐备",
        res["confidence_mix"]["high"] == 1 and res["confidence_mix"]["medium"] == 2
        and res["confidence_mix"]["low"] == 1)
    chk("证据绑定率达标退出码 0", res["exit_code"] == errors.OK)

    forged = [{"id": "f1", "text": "指向不存在的文件", "evidence": {"type": "file",
                                                            "ref": "nope.py", "lines": [1, 2]}}]
    fr = verify(forged, str(tmp))
    chk("文件不存在 -> forged", fr["forged"] == 1)
    chk("伪造证据命中 RL-C04（退出码5）", fr["redline"] and fr["redline"]["id"] == "RL-C04"
        and fr["exit_code"] == errors.REDLINE_CRITICAL)
    chk("RL-C04 报告含 must_retract", fr["redline"]["must_retract"] == ["f1"])

    oor = [{"id": "o1", "text": "行号越界", "evidence": {"type": "file", "ref": "a.py",
                                                    "lines": [3, 999]}}]
    chk("行号越界 -> forged", verify(oor, str(tmp))["forged"] == 1)

    no_ev = [{"id": "n1", "text": "没有证据字段"}]
    ne = verify(no_ev, str(tmp))
    chk("缺 evidence 字段被标 forged", ne["forged"] == 1 and ne["exit_code"] == errors.REDLINE_CRITICAL)

    mostly_unverified = [{"id": "u%d" % i, "text": "x", "evidence": {"type": "unverified"}}
                         for i in range(5)]
    mr = verify(mostly_unverified, str(tmp))
    chk("绑定率不足 -> QUALITY_UNMET", mr["exit_code"] == errors.QUALITY_UNMET and
        mr["verdict"] == "unmet")

    sentinel_missing = [{"id": "s1", "text": "长跑任务", "evidence": {"type": "cmd",
                                                                 "sentinel": "no.sentinel"}}]
    chk("sentinel 缺失 -> forged", verify(sentinel_missing, str(tmp))["forged"] == 1)
    bad_type = [{"id": "b1", "text": "未知类型", "evidence": {"type": "vibe"}}]
    chk("未知证据类型 -> forged", verify(bad_type, str(tmp))["forged"] == 1)
    chk("结果确定性", verify(good, str(tmp))["rows"] == verify(good, str(tmp))["rows"])
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "claims"))
