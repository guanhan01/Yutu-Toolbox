# -*- coding: utf-8 -*-
"""FP-10 策略检索命中 / FP-11-12 策略候选·灰度·晋升·回滚（含人工硬关卡）。

设计要点（对应 PLATFORM_RESEARCH §3 / PRD FP-10~FP-12）：
- 事实源只有一处：`$CE_HOME/strategies.jsonl`（**append-only 事件流**）；
  `strategies/INDEX.md` 与 `strategies/<id>.md` 是**派生视图**，由 `sync` 单向生成，任何人不得手改；
- 状态 = 事件流确定性重放的结果（同输入必同输出，可回归）；
- 晋升必须 `--confirmed-by`（人工）+ 确认令牌，缺一即以退出码 3 停住（公理Ⅳ / RL-S03）；
- 容量上限、时间衰减、退役天数全部从 tech_spec 取，禁止脚本内硬编码。

用法：
  ce strategy search  --task-text "..." [--task-class design] [--state-root DIR]
  ce strategy sync    [--state-root DIR]
  ce strategy list    [--state-root DIR]
  ce strategy record-outcome --id S-0101 --outcome accepted --signal strong [--run-id RID]
  ce strategy promote --id S-0101 --confirmed-by "human:xxx" --token <token>
  ce strategy rollback --id S-0101 --reason "..."
"""

import argparse
import datetime
import json
import os
import sys
from pathlib import Path

from _lib import cli, errors, jsonio, paths as P, schema as S

EVENT_TYPES = ("seed", "view", "hit", "outcome", "promote", "retire", "rollback")


# ---------------- 事件流与派生状态 ----------------

def _now():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def event_file(root):
    return P.strategies_jsonl(root)


def read_events(root):
    rows = []
    for obj in jsonio.read_jsonl(event_file(root)):
        if isinstance(obj, dict) and obj.get("type") in EVENT_TYPES:
            rows.append(obj)
    return rows


def append_event(root, obj, run_id=None):
    obj = dict(obj)
    obj.setdefault("schema_version", S.STRATEGY_SCHEMA)
    obj.setdefault("ts", _now())
    if run_id:
        obj.setdefault("run_id", run_id)
    jsonio.ensure_parent(event_file(root))
    with jsonio.FileLock(event_file(root)):
        jsonio.append_jsonl(event_file(root), obj, lock=False)
    return obj


def _days_since(ts):
    try:
        t = datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
        return (datetime.datetime.utcnow() - t).total_seconds() / 86400.0
    except Exception:
        return 0.0


def replay(root=None, seed_path=None):
    """把事件流重放成策略状态 dict。纯函数式（相同事件流 -> 相同结果）。"""
    events = read_events(root) if root else []
    spec = S.spec_get("strategy") or {}
    decay = float(spec.get("capacity", {}).get("decay_per_day", 0.03))
    retire_days = float(spec.get("capacity", {}).get("retire_days", 90))

    store = {}
    for ev in events:
        sid = ev.get("id")
        if not sid:
            continue
        t = ev.get("type")
        if t == "seed":
            entry = {k: v for k, v in ev.items() if k not in ("type", "ts", "schema_version")}
            entry.setdefault("status", "seed")
            entry.setdefault("views", 0)
            entry.setdefault("hits", 0)
            entry.setdefault("success", 0)
            entry.setdefault("failure", 0)
            entry.setdefault("strong_signals", 0)
            entry.setdefault("neg_signals", 0)
            entry.setdefault("created", ev.get("ts"))
            store[sid] = entry
            continue
        e = store.get(sid)
        if e is None:
            continue
        if t == "view":
            e["views"] = int(e.get("views", 0)) + 1
        elif t == "hit":
            e["hits"] = int(e.get("hits", 0)) + 1
            e["last_seen"] = ev.get("ts")
        elif t == "outcome":
            if ev.get("outcome") == "accepted":
                e["success"] = int(e.get("success", 0)) + 1
            else:
                e["failure"] = int(e.get("failure", 0)) + 1
            # 信号强度累计（对应 O-2 G2/G3/G6：强信号计入晋升计数，负信号零容忍）
            sig = ev.get("signal")
            if ev.get("counted_toward_promotion") or sig == "strong":
                e["strong_signals"] = int(e.get("strong_signals", 0)) + 1
            if ev.get("outcome") in ("rework", "failed") or sig == "strong_negative":
                e["neg_signals"] = int(e.get("neg_signals", 0)) + 1
            e["last_outcome_ts"] = ev.get("ts")
        elif t == "promote":
            e["status"] = "promoted"
            e["promoted_ts"] = ev.get("ts")
            e["confirmed_by"] = ev.get("confirmed_by")
        elif t == "retire":
            e["status"] = "retired"
            e["retired_ts"] = ev.get("ts")
            e["retire_reason"] = ev.get("reason")
        elif t == "rollback":
            e["status"] = "promoted" if ev.get("restored") else "gray"
            e["rollback_ts"] = ev.get("ts")
        e["updated"] = ev.get("ts")

    for sid, e in store.items():
        hits = int(e.get("hits", 0))
        succ = int(e.get("success", 0))
        rate = (succ / float(hits)) if hits else 0.0
        age = _days_since(e.get("updated") or e.get("created") or _now())
        e["success_rate"] = round(rate, 4)
        e["age_days"] = round(age, 2)
        e["score"] = round((hits * 0.5 + succ * 1.0) * ((1.0 - decay) ** age), 4)
        if e.get("status") in ("seed", "gray", "promoted") and age > retire_days:
            e["auto_retire"] = True
    return store


def seed_events():
    p = P.references_dir() / "strategy-seeds.jsonl"
    out = []
    for obj in jsonio.read_jsonl(p):
        if not isinstance(obj, dict):
            continue
        obj = dict(obj)
        obj["type"] = "seed"
        obj.setdefault("status", "seed")
        out.append(obj)
    return out


def install_seeds(root, seeds=None, created_ts=None):
    """首次初始化时把种子策略写入事件流（幂等：已存在同 id 的 seed 事件则跳过）。

    created_ts 供确定性测试把 created 时间回拨，用于验证冷却期判定（不改变晋升硬关卡强度）。
    """
    existing = set(ev.get("id") for ev in read_events(root) if ev.get("type") == "seed")
    added = 0
    for s in (seeds if seeds is not None else seed_events()):
        if s.get("id") in existing:
            continue
        payload = dict(s)
        if created_ts:
            payload["ts"] = created_ts
            payload["created"] = created_ts
        append_event(root, payload)
        added += 1
    return added


# ---------------- 检索 ----------------

def _match_score(entry, tokens, task_class):
    keys = [str(k).lower() for k in (entry.get("feature_keys") or [])]
    text = " ".join([str(entry.get("title", "")), str(entry.get("guidance", ""))] + keys).lower()
    score = 0.0
    for tok in tokens:
        tok = str(tok).lower()
        if len(tok) < 2:
            continue
        if tok in keys:
            score += 2.0
        elif tok in text:
            score += 0.5
    if task_class and entry.get("task_class") in (task_class, "any"):
        score += 1.0 if entry.get("task_class") == task_class else 0.5
    return score


def search(root, task_text="", task_class=None, feature_keys=None, limit=None):
    """命中检索：返回 score>0 的 top-N。纯确定性。"""
    spec = S.spec_get("strategy") or {}
    max_inject = int(spec.get("max_inject", 3) if limit is None else limit)
    store = replay(root)
    tokens = [t for t in (str(task_text).replace("，", " ").replace(",", " ").split()) if t]
    tokens += [str(k) for k in (feature_keys or [])]
    scored = []
    for sid, e in store.items():
        if e.get("status") == "retired":
            continue
        sc = _match_score(e, tokens, task_class)
        if sc > 0:
            scored.append({"id": sid, "title": e.get("title"), "status": e.get("status"),
                           "task_class": e.get("task_class"), "match_score": round(sc, 3),
                           "hits": int(e.get("hits", 0)), "success_rate": e.get("success_rate", 0.0),
                           "gist": (e.get("guidance") or "")[:400]})
    scored.sort(key=lambda x: (-x["match_score"], -x["success_rate"], x["id"]))
    return scored[:max_inject]


# ---------------- 派生视图 ----------------

def sync(root):
    """重建派生视图（INDEX.md + strategies/<id>.md）。唯一写入者。"""
    store = replay(root)
    spec = S.spec_get("strategy") or {}
    max_lines = int(spec.get("index_max_lines", 100))
    sdir = P.strategies_dir(root)
    jsonio.ensure_parent(sdir / "_")

    entries = sorted(store.values(), key=lambda e: (-e.get("score", 0.0), e.get("id", "")))
    lines = [
        "# 策略索引（派生视图，勿手改）",
        "",
        "> 由 `strategy.py sync` 从 strategies.jsonl 单向生成；正文在同级 <id>.md",
        "",
        "| id | 状态 | 适用类 | 命中 | 成功率 | 要点 |",
        "|---|---|---|---|---|---|",
    ]
    truncated = []
    for e in entries:
        row = "| %s | %s | %s | %d | %.2f | %s |" % (
            e.get("id"), e.get("status"), e.get("task_class"), int(e.get("hits", 0)),
            float(e.get("success_rate", 0.0)),
            str(e.get("title", "")).replace("|", "/")[:40])
        if len(lines) + 1 > max_lines:
            truncated.append(e.get("id"))
            continue
        lines.append(row)
    lines.append("")
    lines.append("共 %d 条，索引上限 %d 行%s" % (
        len(entries), max_lines,
        ("，已按分数截断：%s" % ",".join(truncated) if truncated else "")))
    jsonio.atomic_write_text(P.strategy_index_md(root), "\n".join(lines) + "\n")

    written = []
    for sid, e in store.items():
        body = [
            "# %s %s" % (sid, e.get("title", "")),
            "",
            "- 状态：%s" % e.get("status"),
            "- 适用任务类：%s" % e.get("task_class"),
            "- 特征键：%s" % ", ".join(str(k) for k in (e.get("feature_keys") or [])),
            "- 命中/成功/失败：%d / %d / %d" % (int(e.get("hits", 0)), int(e.get("success", 0)),
                                          int(e.get("failure", 0))),
            "- 来源：%s" % e.get("source", "-"),
            "",
            "## 指导语",
            "",
            str(e.get("guidance", "")).strip() or "（空）",
            "",
        ]
        p = sdir / ("%s.md" % sid)
        jsonio.atomic_write_text(p, "\n".join(body))
        written.append(str(p))
    return {"entries": len(store), "index": str(P.strategy_index_md(root)),
            "index_lines": len(lines), "truncated": truncated, "written": written}


# ---------------- 晋升 / 回滚（含硬关卡）----------------

def _parse_threshold(expr):
    """把 signal-model.json gates.candidate 的 'X op N' 表达式解析成 (op, value)。"""
    import re as _re
    m = _re.search(r"([<>]=?|==)\s*([0-9.]+)", expr or "")
    if not m:
        return None, None
    return m.group(1), float(m.group(2))


def _cmp(value, op, target):
    if op is None:
        return True
    if op in (">=", "ge"):
        return value >= target
    if op in ("<=", "le"):
        return value <= target
    if op == ">":
        return value > target
    if op == "<":
        return value < target
    if op in ("==", "eq"):
        return abs(value - target) < 1e-9
    return True


def _max_overlap_with_promoted(store, sid):
    """G5：本条目 feature_keys 与所有已 promoted 条目的 Jaccard 相似度最大值。"""
    me = store.get(sid) or {}
    my_keys = set(str(k) for k in (me.get("feature_keys") or []))
    if not my_keys:
        return 0.0
    best = 0.0
    for other in store.values():
        if other.get("id") == sid:
            continue
        if other.get("status") != "promoted":
            continue
        ok = set(str(k) for k in (other.get("feature_keys") or []))
        if not ok:
            continue
        best = max(best, len(my_keys & ok) / float(len(my_keys | ok)))
    return best


def eligibility(root, sid):
    """只读判定：某策略是否满足自动晋升候选门槛（是否批准仍需人工）。

    门槛一律从 references/signal-model.json 的 gates.candidate（G1–G6）读取，
    不再从 tech_spec.strategy.promotion 取旧口径（P0-2：语义桥必须被强制参考）。
    """
    store = replay(root)
    e = store.get(sid)
    if e is None:
        return {"eligible": False, "reason": "not_found"}
    gates = (S.signal_cfg().get("gates", {}) or {}).get("candidate", {}) or {}
    n_hit = int(e.get("hits", 0))
    n_strong = int(e.get("strong_signals", 0))
    n_neg = int(e.get("neg_signals", 0))
    strong_rate = n_strong / float(max(1, n_hit))
    neg_rate = n_neg / float(max(1, n_hit))
    since_h = _days_since(e.get("created") or _now()) * 24.0

    if e.get("status") == "promoted":
        return {"eligible": False, "reason": "already_promoted", "id": sid}

    # G1: n_hit >= 3
    op1, v1 = _parse_threshold(gates.get("G1", "n_hit >= 3"))
    if not _cmp(n_hit, op1, v1):
        return {"eligible": False, "reason": "hits<min", "id": sid,
                "n_hit": n_hit, "required": v1}
    # G2: strong_success_rate >= 0.70
    op2, v2 = _parse_threshold(gates.get("G2", "strong_success_rate >= 0.70"))
    if not _cmp(strong_rate, op2, v2):
        return {"eligible": False, "reason": "strong_rate<min", "id": sid,
                "strong_rate": round(strong_rate, 4), "required": v2}
    # G3: neg_rate == 0（S2/S3负/F3 零容忍）
    op3, v3 = _parse_threshold(gates.get("G3", "neg_rate == 0"))
    if not _cmp(neg_rate, op3, v3):
        return {"eligible": False, "reason": "neg_rate>0", "id": sid,
                "neg_rate": round(neg_rate, 4), "required": v3}
    # G4: age_hours >= 24
    op4, v4 = _parse_threshold(gates.get("G4", "age_hours >= 24"))
    if not _cmp(since_h, op4, v4):
        return {"eligible": False, "reason": "cooldown", "id": sid,
                "hours_since_created": round(since_h, 2), "required": v4}
    # G5: overlap < 0.60（与已 promoted 条目的 feature_keys 相似度，集合 Jaccard 近似）
    g5op, g5v = _parse_threshold(gates.get("G5", "overlap < 0.60"))
    ov = _max_overlap_with_promoted(store, sid)
    if not _cmp(ov, g5op, g5v):
        return {"eligible": False, "reason": "overlap_too_high", "id": sid,
                "overlap": round(ov, 4), "required": g5v}
    # G6: 弱信号不计入 n_strong —— 已在 replay() 累计层强制（仅 counted/strong 计入）
    return {"eligible": True, "id": sid, "n_hit": n_hit,
            "strong_rate": round(strong_rate, 4), "neg_rate": round(neg_rate, 4),
            "overlap": round(ov, 4)}


def promote(root, sid, confirmed_by=None, token=None, run_id=None, dry_run=False):
    """晋升：须经 confirm.py 独立完成人工确认；默认仅出 patch proposal（P0-4）。

    - dry_run=True：只产出「够格判定 + patch proposal」，不写任何晋升事件
      （PRD §11.1 要求脚本默认 dry-run 产出 patch proposal，不决定批不批）
    - 非 dry-run 且无 token：生成待确认提案（need_confirm，退出码 3）
    - 非 dry-run 且带 token：要求 pending 提案已被 confirm.py apply 标记为 confirmed，
      且 confirmed_by 合法（human: 开头、不含 model）；否则拒绝——杜绝模型自批
    """
    gate = eligibility(root, sid)
    if not gate.get("eligible"):
        return {"ok": False, "reason": gate.get("reason"), "detail": gate,
                "exit_code": errors.USAGE}

    if dry_run:
        return {"ok": False, "dry_run": True, "need_confirm": True, "redline": "RL-S03",
                "impact": "策略 %s 成为正式策略，将影响后续任务的发散引导" % sid,
                "rollback": "strategy.py rollback --id %s" % sid,
                "exit_code": errors.NEED_CONFIRM, "eligibility": gate}

    if not confirmed_by or not token:
        proposal_dir = P.pending_dir(root)
        jsonio.ensure_parent(proposal_dir / "_")
        import secrets
        new_token = secrets.token_hex(8)
        rid = "promote-%s-%s" % (sid, new_token[:6])
        req = {"type": "promote", "id": rid, "sid": sid, "token": new_token,
               "created": _now(), "state": "pending",
               "impact": "策略 %s 成为正式策略，将影响后续任务的发散引导" % sid,
               "rollback": "strategy.py rollback --id %s" % sid,
               "requires": "由 confirm.py apply --id %s --token <token> --confirmed-by human:<姓名> 完成人工确认" % rid}
        p = proposal_dir / ("%s.json" % rid)
        jsonio.atomic_write_json(p, req)
        return {"ok": False, "need_confirm": True, "redline": "RL-S03",
                "request_id": rid, "request_file": str(p), "token": new_token,
                "impact": req["impact"], "rollback": req["rollback"],
                "exit_code": errors.NEED_CONFIRM}

    # 校验令牌 + 确认状态（不可逆动作硬关卡：必须由 confirm.py 标记 confirmed）
    pending = P.pending_dir(root)
    reqs = [f for f in pending.glob("promote-%s-*.json" % sid)] if pending.exists() else []
    matched = None
    for f in reqs:
        try:
            obj = jsonio.read_json(f)
        except Exception:
            continue
        if obj.get("token") == token and obj.get("sid") == sid:
            matched = f
            break
    if matched is None:
        return {"ok": False, "reason": "bad_or_missing_token", "exit_code": errors.NEED_CONFIRM}
    obj = jsonio.read_json(matched)
    if obj.get("state") != "confirmed":
        return {"ok": False, "reason": "not_confirmed_yet",
                "detail": "必须由 confirm.py apply 先完成人工确认，禁止命令行直接自批",
                "exit_code": errors.NEED_CONFIRM}
    cb = obj.get("confirmed_by", "")
    if "model" in str(cb).lower() or not str(cb).startswith("human:"):
        return {"ok": False, "reason": "invalid_confirmed_by",
                "detail": "confirmed_by 必须以 human: 开头且不含 model",
                "exit_code": errors.NEED_CONFIRM}

    ev = append_event(root, {"type": "promote", "id": sid, "confirmed_by": cb,
                             "token_prefix": token[:6]}, run_id=run_id)
    try:
        matched.unlink()
    except Exception:
        pass
    return {"ok": True, "promoted": sid, "confirmed_by": cb, "event": ev,
            "exit_code": errors.OK}


def rollback(root, sid, reason="manual rollback"):
    ev = append_event(root, {"type": "rollback", "id": sid, "reason": reason})
    return {"ok": True, "rolled_back": sid, "event": ev}


# ---------------- CLI ----------------

def main(argv=None):
    p = cli.parser_for("strategy", __doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, help_text, fn):
        sp = sub.add_parser(name, help=help_text)
        return sp, fn

    sp = sub.add_parser("search", help="按任务文本检索命中策略")
    sp.add_argument("--task-text", default="")
    sp.add_argument("--task-class", default=None)
    sp.add_argument("--feature-keys", default="", help="逗号分隔")
    sp.add_argument("--limit", type=int, default=None)

    sp = sub.add_parser("list", help="列出派生状态")

    sp = sub.add_parser("sync", help="重建派生视图（INDEX.md 与 <id>.md）")

    sp = sub.add_parser("install-seeds", help="写入种子策略（幂等）")

    sp = sub.add_parser("record-outcome", help="记录本次运行对某策略的结果")
    sp.add_argument("--id", required=True)
    sp.add_argument("--outcome", required=True, choices=["accepted", "rework", "failed"])
    sp.add_argument("--signal", default="weak", choices=["strong", "weak"],
                    help="成功信号强度（strong 计入晋升计数；weak 只留痕）")
    sp.add_argument("--source", default="explicit_command",
                    help="采集通道：explicit_command=ce accept/reject；self_report_of_user_utterance=口头转写折半")

    sp = sub.add_parser("promote", help="晋升为正式策略（需人工确认）")
    sp.add_argument("--id", required=True)
    sp.add_argument("--confirmed-by", default=None)
    sp.add_argument("--token", default=None)

    sp = sub.add_parser("rollback", help="回滚策略到灰度/种子态")
    sp.add_argument("--id", required=True)
    sp.add_argument("--reason", default="manual rollback")

    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    _argv = list(argv) if argv is not None else sys.argv[1:]
    if "--selftest" in _argv:
        return cli.run_selftest(self_test(), name="strategy")
    args = p.parse_args(argv)

    if args.selftest:
        return cli.run_selftest(self_test(), name="strategy")

    root = cli.resolve_state(args)
    root.mkdir(parents=True, exist_ok=True)

    if args.cmd == "search":
        keys = [k for k in args.feature_keys.split(",") if k.strip()]
        hits = search(root, args.task_text, args.task_class, keys, args.limit)
        return cli.ok_out({"hits": hits, "count": len(hits),
                           "max_inject": int(S.spec_get("strategy.max_inject", None, 3)),
                           "state_root": str(root)})
    if args.cmd == "list":
        store = replay(root)
        rows = []
        for sid in sorted(store):
            e = store[sid]
            rows.append({"id": sid, "status": e.get("status"), "title": e.get("title"),
                         "hits": e.get("hits"), "success": e.get("success"),
                         "score": e.get("score"), "auto_retire": bool(e.get("auto_retire"))})
        return cli.ok_out({"entries": rows, "count": len(rows)})
    if args.cmd == "sync":
        res = sync(root)
        return cli.ok_out(res)
    if args.cmd == "install-seeds":
        n = install_seeds(root)
        return cli.ok_out({"installed": n, "state_root": str(root)})
    if args.cmd == "record-outcome":
        signal = args.signal
        source = args.source
        factor, ch = S.feedback_channel_factor(source)
        # O-2 已落地：strong 信号计数入晋升；P-2 双通道折权（口头转写 effective 权重 0.5）
        counted = (signal == "strong") and (factor > 0)
        ev = append_event(root, {"type": "outcome", "id": args.id, "outcome": args.outcome,
                                 "signal": signal, "source": source,
                                 "counted_toward_promotion": counted}, run_id=args.run_id)
        note = "O-2 已落地：strong 信号计数入晋升；P-2 通道=%s 折权系数=%s" % (ch, factor)
        return cli.ok_out({"recorded": ev, "counted_toward_promotion": counted,
                           "feedback_channel": ch, "weight_factor": factor, "note": note})
    if args.cmd == "promote":
        res = promote(root, args.id, args.confirmed_by, args.token, run_id=args.run_id)
        return cli.finalize(res, res.get("exit_code", errors.OK))
    if args.cmd == "rollback":
        res = rollback(root, args.id, args.reason)
        return cli.ok_out(res)
    return cli.err_out("unknown cmd", errors.USAGE)


def self_test():
    checks = []
    import tempfile

    def chk(name, cond):
        checks.append((name, bool(cond)))

    seeds_ok = len(seed_events()) >= 12
    chk("种子策略 ≥12 条", seeds_ok)
    old_ts = (datetime.datetime.utcnow() - datetime.timedelta(days=3)).replace(
        microsecond=0).isoformat() + "Z"
    with tempfile.TemporaryDirectory() as td:
        install_seeds(td, created_ts=old_ts)
        n1 = len([e for e in read_events(td) if e.get("type") == "seed"])
        install_seeds(td, created_ts=old_ts)
        n2 = len([e for e in read_events(td) if e.get("type") == "seed"])
        chk("install_seeds 幂等", n1 == n2 and n1 >= 12)
        hits = search(td, "并发 超卖 幂等")
        chk("检索命中至少一条", len(hits) >= 1)
        chk("命中不超过 max_inject", len(hits) <= int(S.spec_get("strategy.max_inject", None, 3)))
        chk("检索结果确定性", hits == search(td, "并发 超卖 幂等"))
        sid = hits[0]["id"]
        chk("未满足次数门槛时不可晋升", eligibility(td, sid)["eligible"] is False)
        for _ in range(3):
            append_event(td, {"type": "hit", "id": sid})
            append_event(td, {"type": "outcome", "id": sid, "outcome": "accepted",
                              "signal": "strong"})
        el = eligibility(td, sid)
        chk("凑足门槛后 eligible=True", el["eligible"] is True)
        pr = promote(td, sid, confirmed_by=None, token=None)
        chk("无确认时返回 need_confirm + 退出码3",
            pr.get("need_confirm") is True and pr.get("exit_code") == errors.NEED_CONFIRM)
        dr = promote(td, sid, dry_run=True)
        chk("dry_run 只出 proposal 不晋升", dr.get("dry_run") is True and dr.get("ok") is False)
        bad = promote(td, sid, confirmed_by="human:x", token="deadbeefdeadbeef")
        chk("错误令牌被拒（不晋升）",
            bad.get("ok") is False and bad.get("reason") == "bad_or_missing_token")
        # 正确流程：promote 生成提案 -> confirm.py apply 完成人工确认 -> 再 promote 放行
        from confirm import apply as confirm_apply
        rid = pr.get("request_id")
        ca = confirm_apply(td, rid, pr.get("token"), "human:tester")
        chk("confirm.py apply 标记 confirmed", ca.get("ok") is True)
        good = promote(td, sid, confirmed_by="human:tester", token=pr.get("token"))
        chk("经 confirm.py 确认后晋升", good.get("ok") is True)
        chk("晋升后状态 promoted", replay(td).get(sid, {}).get("status") == "promoted")
        rb = rollback(td, sid)
        chk("rollback 落事件", rb.get("ok") is True)
        chk("rollback 后回到 gray", replay(td).get(sid, {}).get("status") == "gray")
        res = sync(td)
        chk("sync 生成 INDEX.md", Path(res["index"]).exists())
        chk("INDEX 不超上限",
            res["index_lines"] <= int(S.spec_get("strategy.index_max_lines", None, 100)))
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "strategy"))
