# -*- coding: utf-8 -*-
"""Trace 落盘：每行一个事件的结构化轨迹（schema_version 稳定是测评做过程对比的前提）。

字段设计见 PLATFORM_RESEARCH §4.1：时间戳 / 阶段·步骤标识 / 输入输出引用 / 度量。
成本画像（p50/p95/命中率等）由每个 run 的 trace 汇总得出，不新增第二套埋点。
"""

import datetime
import json
import os
import time
from pathlib import Path

from . import paths as _paths
from . import jsonio as _jsonio
from . import schema as _schema


def now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def new_run_id():
    """时间前缀 + 短随机（secrets 为标准库），可排序且不易撞号。"""
    import secrets
    stamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return "%s-%s" % (stamp, secrets.token_hex(4))


class Tracer(object):
    """绑定某个 run 的 Trace 写入器。进程内自增 seq，保证事件顺序可复原。"""

    def __init__(self, state_root, run_id, stage=None):
        self.state_root = state_root
        self.run_id = run_id
        self.file = _paths.trace_file(state_root, run_id)
        _jsonio.ensure_parent(self.file)
        _paths.ensure_dir(_paths.trace_dir(state_root))
        self._seq = _jsonio.count_lines(self.file)
        self.stage = stage

    def emit(self, step, status="ok", metrics=None, decision=None, io=None, error=None,
             stage=None, policy_hits=None, redline=None, extra=None):
        self._seq += 1
        event = {
            "schema_version": _schema.TRACE_SCHEMA,
            "ts": now_iso(),
            "run_id": self.run_id,
            "seq": self._seq,
            "stage": stage or self.stage or "unknown",
            "step": step,
            "status": status,
            "io": io or {},
            "metrics": metrics or {},
            "decision": decision or {},
            "policy_hits": policy_hits or [],
            "redline": redline or {"checked": False},
            "error": error,
        }
        if extra:
            event.update(extra)
        _jsonio.append_jsonl(self.file, event)
        return event

    def timeit(self, step, **kw):
        """上下文管理器：自动记录 latency_ms。用法 with tr.timeit('diverge'): ..."""
        return _TimeIt(self, step, **kw)


class _TimeIt(object):
    def __init__(self, tracer, step, **kw):
        self.tr = tracer
        self.step = step
        self.kw = kw
        self.t0 = None

    def __enter__(self):
        self.t0 = time.time()
        return self

    def __exit__(self, exc_type, exc, tb):
        metrics = dict(self.kw.get("metrics") or {})
        metrics["latency_ms"] = int(round((time.time() - self.t0) * 1000))
        kw = dict(self.kw)
        kw["metrics"] = metrics
        if exc_type is not None:
            kw["status"] = "error"
            kw["error"] = {"type": exc_type.__name__, "message": str(exc)}
        self.tr.emit(self.step, **kw)
        return False  # 不吞异常


def read_events(state_root, run_id):
    return _jsonio.read_jsonl(_paths.trace_file(state_root, run_id))


def validate_events(events):
    """校验 Trace 是否可解析且必填字段完整（供审计与回放使用）。"""
    problems = []
    for idx, ev in enumerate(events):
        miss = _schema.missing_fields(ev, _schema.TRACE_REQUIRED)
        if miss:
            problems.append({"line": idx + 1, "missing": miss})
        if ev.get("schema_version") not in (None, _schema.TRACE_SCHEMA):
            problems.append({"line": idx + 1, "schema_version": ev.get("schema_version")})
    return (len(problems) == 0), problems


def summarize(state_root, run_id):
    """从 trace 汇总成本画像：延迟分位、token 估算、候选数、策略命中、降级事件。"""
    events = read_events(state_root, run_id)
    latency = [int(ev.get("metrics", {}).get("latency_ms", 0) or 0) for ev in events]
    latency = [x for x in latency if x > 0]
    tokens_in = sum(int(ev.get("metrics", {}).get("tokens_est_in", 0) or 0) for ev in events)
    tokens_out = sum(int(ev.get("metrics", {}).get("tokens_est_out", 0) or 0) for ev in events)
    lat_sorted = sorted(latency)
    def pct(p):
        if not lat_sorted:
            return 0
        k = int(round((len(lat_sorted) - 1) * p))
        return lat_sorted[k]
    degrade = [ev for ev in events if (ev.get("decision") or {}).get("degraded")]
    return {
        "run_id": run_id,
        "events": len(events),
        "latency_ms": {"p50": pct(0.5), "p95": pct(0.95), "max": max(lat_sorted) if lat_sorted else 0},
        "tokens_est": {"in": tokens_in, "out": tokens_out, "total": tokens_in + tokens_out},
        "cache_hit_rate": _rate(events, lambda ev: bool(ev.get("metrics", {}).get("cache_hit"))),
        "policy_hit_events": len([e for e in events if e.get("policy_hits")]),
        "degrade_events": [{"stage": e.get("stage"), "step": e.get("step"),
                            "reason": (e.get("decision") or {}).get("why")} for e in degrade],
        "errors": [{"stage": e.get("stage"), "step": e.get("step"), "error": e.get("error")}
                   for e in events if e.get("status") == "error"],
    }


def _rate(events, pred):
    if not events:
        return 0.0
    return round(sum(1 for e in events if pred(e)) / float(len(events)), 4)


def self_test(state_root=None):
    """端到端自测：写 trace -> 读回 -> 校验 -> 汇总。需要临时目录。"""
    import tempfile
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    tmp = Path(state_root or tempfile.mkdtemp(prefix="ce-trace-"))
    rid = "selftest-" + datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    tr = Tracer(str(tmp), rid, stage="selftest")
    tr.emit("step_a", metrics={"tokens_est_in": 100, "latency_ms": 5})
    tr.emit("step_b", metrics={"tokens_est_in": 200, "latency_ms": 15}, status="error",
            error={"type": "Dummy", "message": "x"})
    events = read_events(str(tmp), rid)
    chk("事件已落盘", len(events) == 2)
    ok, probs = validate_events(events)
    chk("Trace 通过 schema 校验", ok and not probs)
    chk("seq 自增", [e["seq"] for e in events] == [1, 2])
    s = summarize(str(tmp), rid)
    chk("汇总 token 累加正确", s["tokens_est"]["in"] == 300)
    chk("汇总捕获 error 事件", len(s["errors"]) == 1)
    chk("延迟 p95 ≥ p50", s["latency_ms"]["p95"] >= s["latency_ms"]["p50"])
    return checks
