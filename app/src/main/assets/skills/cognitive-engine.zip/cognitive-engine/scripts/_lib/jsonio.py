# -*- coding: utf-8 -*-
"""原子写 / 备份 / lockfile / JSONL 读写。

为什么手写 lockfile 而不用第三方：约束是零第三方依赖 + Windows 一等公民。
实现：`O_CREAT|O_EXCL` 创建排他锁文件（Windows 与 POSIX 均支持），带过期清理；
写入一律「tmp -> os.replace」，保证进程被杀也不会留下半截文件（脏状态的第一来源）。
"""

import hashlib
import json
import os
import time
from pathlib import Path

LOCK_TIMEOUT_S = 15.0
LOCK_STALE_S = 60.0
LOCK_RETRY_S = 0.05


class FileLock(object):
    """跨平台排他锁（尽力而为，不依赖 fcntl/msvcrt 差异行为）。"""

    def __init__(self, target, timeout=LOCK_TIMEOUT_S, stale=LOCK_STALE_S):
        self.lock_path = Path(str(target) + ".lock")
        self.timeout = timeout
        self.stale = stale
        self.acquired = False

    def _try_acquire(self):
        try:
            fd = os.open(str(self.lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except OSError:
            return False
        try:
            os.write(fd, ("%d %f" % (os.getpid(), time.time())).encode("utf-8"))
        finally:
            os.close(fd)
        self.acquired = True
        return True

    def _break_if_stale(self):
        try:
            st = self.lock_path.stat()
        except OSError:
            return
        if (time.time() - st.st_mtime) > self.stale:
            try:
                self.lock_path.unlink()
            except OSError:
                pass

    def acquire(self):
        deadline = time.time() + self.timeout
        while True:
            if self._try_acquire():
                return True
            self._break_if_stale()
            if time.time() >= deadline:
                return False
            time.sleep(LOCK_RETRY_S)

    def release(self):
        if self.acquired:
            try:
                self.lock_path.unlink()
            except OSError:
                pass
            self.acquired = False

    def __enter__(self):
        if not self.acquire():
            raise IOError("无法获取锁（可能被其他进程占用）：%s" % self.lock_path)
        return self

    def __exit__(self, *exc):
        self.release()
        return False


def _fsync_dir(path):
    try:
        fd = os.open(str(path), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except Exception:
        pass  # 某些平台不允许 fsync 目录，忽略即可


def atomic_write_text(path, text, backup=False, encoding="utf-8"):
    """原子写文本。backup=True 时先把旧文件搬到同级 .bak。"""
    p = Path(path)
    ensure_parent(p)
    if backup and p.exists():
        backup_copy(p)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(str(tmp), "w", encoding=encoding, newline="\n") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(str(tmp), str(p))
    return p


def atomic_write_json(path, data, backup=False, sort_keys=True):
    text = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=sort_keys)
    return atomic_write_text(path, text, backup=backup)


def ensure_parent(path):
    p = Path(path)
    if p.parent and not p.parent.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
    return p


def backup_copy(path):
    src = Path(path)
    if not src.exists():
        return None
    dst = src.with_suffix(src.suffix + ".bak")
    dst.write_bytes(src.read_bytes())
    return dst


def read_text(path, encoding="utf-8"):
    return Path(path).read_text(encoding=encoding)


def read_json(path):
    with open(str(path), "r", encoding="utf-8") as fh:
        return json.load(fh)


def safe_read_json(path, default=None, quarantine_dir=None):
    """读取 JSON，损坏时隔离到 quarantine 而不是静默丢失（TC-24）。

    返回 (data, incident)；incident 为 None 表示正常。
    """
    try:
        return read_json(path), None
    except Exception as exc:  # 明确记录，不静默
        incident = {"error": "%s: %s" % (type(exc).__name__, exc), "quarantined_to": None}
        p = Path(path)
        if p.exists():
            qdir = Path(quarantine_dir) if quarantine_dir else (p.parent / "corrupt")
            ensure_parent(qdir / "_")
            target = qdir / ("%s.corrupt-%d" % (p.name, int(time.time())))
            try:
                target.write_bytes(p.read_bytes())
                incident["quarantined_to"] = str(target)
            except Exception as qexc:
                incident["quarantine_error"] = str(qexc)
        return ({} if default is None else default), incident


def read_jsonl(path):
    rows = []
    p = Path(path)
    if not p.exists():
        return rows
    with open(str(p), "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                rows.append({"__unparsable__": line})
    return rows


def append_jsonl(path, obj, lock=True):
    """追加一行 JSONL；整行一次写入 + 锁保护，避免并发交错撕裂。"""
    p = Path(path)
    ensure_parent(p)
    line = json.dumps(obj, ensure_ascii=False, sort_keys=True) + "\n"

    def _do():
        with open(str(p), "a", encoding="utf-8", newline="\n") as fh:
            fh.write(line)
            fh.flush()
            os.fsync(fh.fileno())

    if lock:
        with FileLock(p):
            _do()
    else:
        _do()
    return p


def count_lines(path):
    p = Path(path)
    if not p.exists():
        return 0
    n = 0
    with open(str(p), "r", encoding="utf-8") as fh:
        for _ in fh:
            n += 1
    return n


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_file(path, chunk=65536):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        while True:
            block = fh.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def sha256_obj(obj):
    return sha256_text(json.dumps(obj, ensure_ascii=False, sort_keys=True))


def self_test():
    """纯函数层自测（无副作用的部分）。"""
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    chk("sha256_obj 稳定", sha256_obj({"a": 1, "b": 2}) == sha256_obj({"b": 2, "a": 1}))
    chk("sha256_obj 敏感", sha256_obj({"a": 1}) != sha256_obj({"a": 2}))
    chk("read_jsonl 空文件返回 []", read_jsonl("__definitely_missing__.jsonl") == [])
    return checks
