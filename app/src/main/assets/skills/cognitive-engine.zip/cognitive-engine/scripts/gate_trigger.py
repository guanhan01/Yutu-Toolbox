# -*- coding: utf-8 -*-
"""FP-01/FP-02 触发门控与档位选择（主链路第 2 节点）。

为什么必须脚本化（公理Ⅱ）：「这个任务值不值得深想」是有确定答案的判定
——画像得分、排除项、净收益预判全是可算的量；交给模型临场感觉会直接导致
过度触发（浪费 token）或漏触发（该深想的没深想），两者都是产品级失败。

定稿口径（PRD §11.2.2 原则 1）：**档位选择零依赖 token 估算**。
进哪个档只看 U/C/I/V/R 画像得分；token/字符只用来判「是否触顶」（由 budget.py 负责）。

用法：
  ce gate judge --task "重新设计订单幂等方案，涉及 4 个文件" --files 4 --steps 6
  ce gate judge --task-file <path> [--json-evidence <evidence.json>]
  ce gate bands                # 打印当前生效的档位表（含 P-1 开关状态）
"""

from _lib import cli, errors, jsonio, schema as S

DIMENSIONS = ("U", "C", "I", "V", "R")

# 硬性排除项 E1..E6 / N7 的关键词证据（仅作**辅助**，显式参数优先级更高）
_KW = {
    "E1": ("import 排序", "import排序", "重命名", "rename", "格式转换", "convert to",
           "replace all", "批量替换", "sort imports"),
    "E2": ("是什么", "什么意思", "翻译", "translate", "查一下", "术语"),
    "E3": ("就按我说的", "按我给的方案", "直接用这个方案", "already decided",
           "照我说的做"),
    "E4": ("写首诗", "写个故事", "creative writing", "写段文案", "编个段子"),
    "E6": ("pptx", "docx", "xlsx", "pdf", "生成 PPT", "生成文档", "导出表格"),
    "N7": ("just do it", "别废话", "直接做", "不用想了", "不用分析"),
}
_APPROACH_KW = ("方案", "备选", "权衡", "对比", "取舍", "是不是应该", "approach",
                "trade-off", "tradeoff", "pros and cons", "优缺点", "还是")
_HEDGE_KW = ("不确定", "不知道该", "几种可能", "maybe", "不确定用哪种", "可能有")
_VERIFY_KW = ("测试", "单测", "test", "schema", "脚本验证", "pytest", "校验脚本", "退出码")
_HIGH_RISK_KW = ("不可逆", "上线", "生产", "删库", "迁移数据", "对外发布", "资金", "安全")


def _kw_hit(text, kws):
    low = (text or "").lower()
    return [k for k in kws if k.lower() in low]


def score_evidence(task_text="", files=0, steps=0, constraints=0, irreversible=0,
                   verifiable=0, approaches=0, rework_cost=0):
    """把外部证据映射成 U/C/I/V/R 五维 0..2 分。**纯函数**——同输入必同输出。"""
    text = task_text or ""
    has = lambda kws: bool(_kw_hit(text, kws))  # noqa: E731

    # U：是否存在 ≥2 个可辩护的路径
    u = 0
    if approaches >= 2:
        u = 2
    elif has(_APPROACH_KW):
        u = 2
    elif approaches == 1 or has(_HEDGE_KW):
        u = 1

    # C：规模证据（文件数 / 步骤数 / 硬约束数），满足项越多分越高
    big = sum(1 for x in (files >= 3, steps >= 5, constraints >= 3) if x)
    c = 2 if big >= 2 else (1 if big == 1 else 0)

    # I：不可逆影响
    i = 2 if irreversible >= 2 else (1 if irreversible == 1 else 0)
    if irreversible == 0 and has(_HIGH_RISK_KW):
        i = 1

    # V：产物是否可被测试/脚本/schema 判定
    v = 2 if verifiable >= 2 else (1 if verifiable == 1 else 0)
    if v == 0 and has(_VERIFY_KW):
        v = 1

    # R：返工代价（影响半径）
    r = 2 if rework_cost >= 2 else (1 if rework_cost == 1 else 0)
    if r == 0 and has(_HIGH_RISK_KW):
        r = 1

    return {"U": u, "C": c, "I": i, "V": v, "R": r}


def total_score(dims):
    w = S.spec_get("gating.weights") or {"U": 2.0, "C": 2.0, "I": 1.5, "V": 1.0, "R": 1.0}
    return round(sum(float(w.get(d, 1.0)) * int(dims.get(d, 0)) for d in DIMENSIONS), 3)


def pick_tier(score, irreversible=0, force=False):
    """分值 -> 档位。I≥2 强制 Deep（PRD §2.3 Step 3 + §11.2.3）。"""
    th = S.spec_get("gating.thresholds") or {"Deep": 6.0, "Standard": 3.0, "Lite": 1.0}
    forced = int(S.spec_get("gating.force_trigger_I", None, 2) or 2)
    if int(irreversible or 0) >= forced:
        return "Deep", "force_trigger_I>=%d（影响不可逆，不看分值）" % forced
    if score >= float(th.get("Deep", 6.0)):
        return "Deep", "score>=%.1f" % float(th["Deep"])
    if score >= float(th.get("Standard", 3.0)):
        return "Standard", "score>=%.1f" % float(th["Standard"])
    if score >= float(th.get("Lite", 1.0)):
        return "Lite", "score>=%.1f" % float(th["Lite"])
    return None, "score<%.1f" % float(th.get("Lite", 1.0))


def net_benefit(tier, base_tokens, tier_spec=None):
    """§2.4 净收益预判：引擎开销占基线的比例。>50% 判定为负收益 -> 不触发。"""
    nb = S.spec_get("gating.net_benefit") or {}
    fixed = float(nb.get("engine_fixed_tokens", 2300))
    per_cand = float(nb.get("per_candidate_tokens", 500))
    ok_ratio = float(nb.get("overhead_ok_ratio", 0.3))
    bad_ratio = float(nb.get("overhead_bad_ratio", 0.5))
    fanout = 0
    if tier:
        band = S.band_get(tier, "fanout", None)
        if band is None:
            fanout = int((tier_spec or {}).get("fanout", 0) or 0)
        else:
            fanout = int(band)
    overhead = fixed + per_cand * fanout
    base = float(base_tokens or 0)
    ratio = (overhead / base) if base > 0 else None
    if ratio is None:
        verdict = "unknown"
    elif ratio > bad_ratio:
        verdict = "negative"
    elif ratio > ok_ratio:
        verdict = "marginal"
    else:
        verdict = "ok"
    return {"engine_overhead_tokens": int(overhead), "base_tokens": int(base),
            "overhead_ratio": (round(ratio, 4) if ratio is not None else None),
            "ok_ratio": ok_ratio, "bad_ratio": bad_ratio, "verdict": verdict}


def exclusions(task_text="", files=0, steps=0, base_tokens=0, specialist=None,
               user_says_just_do_it=False, explicit=None):
    """硬排除项判定。返回 [(code, 证据)]。explicit 为显式声明的排除码列表。"""
    hits = []
    if explicit:
        for code in explicit:
            hits.append((code, "显式声明 --exclude"))
    text = task_text or ""
    for code in ("E1", "E2", "E3", "E4", "E6"):
        kw = _kw_hit(text, _KW[code])
        if kw:
            hits.append((code, "关键词：%s" % ",".join(kw[:3])))
    if specialist:
        hits.append(("E6", "专精技能在场：%s（按 FP 让位规则交由专精技能）" % specialist))
    if int(files) <= 1 and int(steps) <= 1 and not text.strip():
        hits.append(("E1", "无规模证据（files<=1 且 steps<=1 且无任务文本）"))
    min_base = int(S.spec_get("gating.min_base_tokens", None, 2000) or 2000)
    if base_tokens and int(base_tokens) < min_base:
        hits.append(("E5", "基线 token %s < %d（引擎开销占比过高）" % (base_tokens, min_base)))
    if user_says_just_do_it or _kw_hit(text, _KW["N7"]):
        hits.append(("N7", "用户显式要求直接执行"))
    seen, uniq = set(), []
    for code, why in hits:
        if code not in seen:
            seen.add(code)
            uniq.append((code, why))
    return uniq


def judge(task_text="", files=0, steps=0, constraints=0, irreversible=0, verifiable=0,
          approaches=0, rework_cost=0, base_tokens=0, specialist=None,
          user_says_just_do_it=False, exclude=None, evidence=None):
    """主判定。返回 dict（含 exit_code），永远不抛异常给调用方。"""
    ev = dict(evidence or {})
    files = int(ev.get("files", files) or 0)
    steps = int(ev.get("steps", steps) or 0)
    constraints = int(ev.get("constraints", constraints) or 0)
    irreversible = int(ev.get("irreversible", irreversible) or 0)
    verifiable = int(ev.get("verifiable", verifiable) or 0)
    approaches = int(ev.get("approaches", approaches) or 0)
    rework_cost = int(ev.get("rework_cost", rework_cost) or 0)
    base_tokens = int(ev.get("base_tokens", base_tokens) or 0)

    exc = exclusions(task_text, files, steps, base_tokens, specialist,
                     user_says_just_do_it, exclude)
    if exc:
        return {"trigger": False, "decision": "no_trigger", "exclusions": exc,
                "reason": "命中硬排除项 %s" % ",".join(c for c, _ in exc),
                "exit_code": errors.NO_TRIGGER}

    dims = score_evidence(task_text, files, steps, constraints, irreversible,
                          verifiable, approaches, rework_cost)
    score = total_score(dims)
    tier, why = pick_tier(score, irreversible)

    payload = {
        "trigger": tier is not None,
        "task_profile": {"score": score, "dims": dims,
                         "weights": S.spec_get("gating.weights") or {}},
        "tier_reason": why,
        "tier": tier,
        "band": S.band_get(tier, "band", None) if tier else None,
        "exclusions": [],
    }
    if tier is None:
        payload["decision"] = "no_trigger"
        payload["reason"] = "画像得分 %.2f 低于 Lite 门槛" % score
        payload["exit_code"] = errors.NO_TRIGGER
        return payload

    # 档位 = 三轨预算配置的权威源（零估算依赖：只用 U/C/I/V/R 决定的 tier）
    band = payload["band"]
    payload["budget"] = {
        "band": band, "tier": tier,
        "mid_tokens": S.band_get(band, "mid_tokens", None),
        "cap_tokens": S.band_get(band, "cap_tokens", None),
        "cap_chars": S.band_get(band, "cap_chars", None),
        "fanout": S.band_get(band, "fanout", None),
        "verify_rounds": S.band_get(band, "verify_rounds", None),
        "redteam": S.band_get(band, "redteam", None),
        "judgment_track": list(S.band_cfg().get("judgment_track") or ["chars"]),
        "note": "档位由画像得分决定，零依赖 token 估算；触顶判定请调用 budget.py",
    }
    nb = net_benefit(tier, base_tokens)
    payload["net_benefit"] = nb
    if nb["verdict"] == "negative":
        payload["trigger"] = False
        payload["decision"] = "no_trigger"
        payload["reason"] = ("引擎开销占比 %.2f > %.2f，深想的净收益为负（PRD §2.4 R-收益3）"
                             % (nb["overhead_ratio"], nb["bad_ratio"]))
        payload["exit_code"] = errors.NO_TRIGGER
        return payload
    if nb["verdict"] == "marginal":
        payload["warning"] = ("开销占比 %.2f 处于灰区（>%.2f），收益不确定，建议在回执中复核"
                              % (nb["overhead_ratio"], nb["ok_ratio"]))
    payload["decision"] = "trigger"
    payload["exit_code"] = errors.OK
    return payload


def load_evidence(path):
    obj = jsonio.read_json(path)
    if not isinstance(obj, dict):
        raise errors.CEError("证据文件必须是 JSON object", errors.USAGE)
    return obj


def main(argv=None):
    p = cli.parser_for("gate_trigger", __doc__, with_state=False)
    sub = p.add_subparsers(dest="cmd", required=False)

    sp = sub.add_parser("judge", help="触发门控 + 档位选择")
    sp.add_argument("--task", default="", help="任务文本（也可用 --task-file）")
    sp.add_argument("--task-file", default=None, help="任务文本文件")
    sp.add_argument("--evidence", default=None, help="证据 JSON：files/steps/constraints/irreversible/verifiable/approaches/rework_cost/base_tokens")
    sp.add_argument("--files", type=int, default=0)
    sp.add_argument("--steps", type=int, default=0)
    sp.add_argument("--constraints", type=int, default=0)
    sp.add_argument("--irreversible", type=int, default=0, choices=[0, 1, 2])
    sp.add_argument("--verifiable", type=int, default=0, choices=[0, 1, 2])
    sp.add_argument("--approaches", type=int, default=0)
    sp.add_argument("--rework-cost", type=int, default=0)
    sp.add_argument("--base-tokens", type=int, default=0, help="不启用本技能时的预计 token 基线")
    sp.add_argument("--specialist", default=None, help="在场的专精技能名（pptx/docx/xlsx/pdf 等）")
    sp.add_argument("--exclude", default="", help="显式排除码，逗号分隔：E1..E6,N7")
    sp.add_argument("--user-says-do-it", action="store_true", help="用户明确要求直接做")

    sub.add_parser("bands", help="打印当前生效档位表（含 P-1 开关）")
    p.add_argument("--selftest", action="store_true", help="运行内嵌确定性自测")
    args = cli.parse_with_globals(p, argv)

    if args.selftest:
        return cli.run_selftest(self_test(), name="gate_trigger")
    if not args.cmd:
        p.print_help()
        return errors.USAGE

    if args.cmd == "bands":
        cfg = S.band_cfg()
        rows = []
        for code in ("S", "M", "L"):
            b = (cfg.get("bands") or {}).get(code) or {}
            rows.append({"band": code, "tier": b.get("tier"), "mid_tokens": b.get("mid_tokens"),
                         "cap_tokens": b.get("cap_tokens"), "cap_chars": b.get("cap_chars"),
                         "fanout": b.get("fanout"), "verify_rounds": b.get("verify_rounds"),
                         "redteam": b.get("redteam")})
        return cli.ok_out({"active": (cfg.get("p1_decision") or {}).get("active"),
                           "judgment_track": cfg.get("judgment_track"),
                           "chars_per_token_safe": S.chars_per_token_safe()[0],
                           "bands": rows}, pretty=args.pretty)

    task = args.task
    if args.task_file:
        task = jsonio.read_text(args.task_file)
    evidence = load_evidence(args.evidence) if args.evidence else None
    exclude = [x.strip().upper() for x in args.exclude.split(",") if x.strip()]
    res = judge(task, files=args.files, steps=args.steps, constraints=args.constraints,
                irreversible=args.irreversible, verifiable=args.verifiable,
                approaches=args.approaches, rework_cost=args.rework_cost,
                base_tokens=args.base_tokens, specialist=args.specialist,
                user_says_just_do_it=args.user_says_do_it, exclude=exclude,
                evidence=evidence)
    res["ok"] = True
    return cli.finalize(res, res.get("exit_code", errors.OK))


def self_test():
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    small = judge(task_text="把这个文件的 import 排序一下", files=1, steps=1)
    chk("单步确定性操作不触发(E1)", small["exit_code"] == errors.NO_TRIGGER and
        any(c == "E1" for c, _ in small["exclusions"]))
    qa = judge(task_text="Go 里的 context 是什么意思？")
    chk("事实问答不触发(E2)", qa["exit_code"] == errors.NO_TRIGGER and
        any(c == "E2" for c, _ in qa["exclusions"]))
    spec = judge(task_text="重构支付链路，涉及 5 个文件", files=5, specialist="pptx")
    chk("专精技能在场让位(E6)", spec["exit_code"] == errors.NO_TRIGGER and
        any(c == "E6" for c, _ in spec["exclusions"]))
    tiny = judge(task_text="重构支付链路", files=5, base_tokens=800)
    chk("基线过小判定负收益不触发", tiny["exit_code"] == errors.NO_TRIGGER and
        any(c == "E5" for c, _ in tiny["exclusions"]))
    jd = judge(task_text="重构支付链路，涉及 5 个文件", files=5, steps=6, constraints=3,
               verifiable=2, rework_cost=1, approaches=3, base_tokens=40000)
    chk("规模+可验证任务触发", jd["trigger"] is True and jd["exit_code"] == errors.OK)
    chk("触发即带 band 与 cap_chars", jd["band"] in ("S", "M", "L") and
        jd["budget"]["cap_chars"] > 0)
    chk("档位选择零依赖估算：无 base_tokens 也能定档",
        judge(task_text="权衡两种幂等方案", files=4, approaches=2)["tier"] is not None)
    irrev = judge(task_text="生产数据迁移", files=2, irreversible=2, base_tokens=60000)
    chk("I>=2 强制 Deep 且真的触发", irrev.get("trigger") is True and
        irrev.get("tier") == "Deep" and irrev["budget"]["band"] == "L")
    # §2.4 R-收益3：即便画像得分很高，只要引擎开销占比 >50%，仍判定不触发
    poor = judge(task_text="重构支付链路", files=9, irreversible=2, base_tokens=9000)
    chk("高分但净收益为负 -> 不触发", poor["exit_code"] == errors.NO_TRIGGER and
        poor.get("net_benefit", {}).get("verdict") == "negative")
    chk("同样的输入两次判定一致",
        judge(task_text="重构支付链路", files=5, steps=6, base_tokens=9000)["task_profile"]["score"]
        == judge(task_text="重构支付链路", files=5, steps=6, base_tokens=9000)["task_profile"]["score"])
    litperson = judge(task_text="写首诗描述秋天")
    chk("创意写作不触发(E4)", litperson["exit_code"] == errors.NO_TRIGGER)
    n7 = judge(task_text="重构支付链路", files=5, user_says_just_do_it=True)
    chk("用户要求直接做则让位(N7)", n7["exit_code"] == errors.NO_TRIGGER and
        any(c == "N7" for c, _ in n7["exclusions"]))
    return checks


if __name__ == "__main__":
    import sys
    sys.exit(cli.safe_dispatch(main, None, "gate_trigger"))
