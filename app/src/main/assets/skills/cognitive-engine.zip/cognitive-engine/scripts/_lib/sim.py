# -*- coding: utf-8 -*-
"""确定性相似度：字符 3-gram Jaccard + TF-IDF 余弦（纯标准库）。

为什么必须脚本化（公理Ⅱ）：候选是否重复是**有确定答案**的问题，交给 LLM 目测不可复现。
实现要点：
- 归一化：小写 + 空白折叠 + 标点统一；
- 中文无空格分词 => 对 CJK 采用「字符 2-gram」当作词项，避免中文文档 TF 全为 1；
- 相似度取 max(char_3gram_jaccard, tfidf_cosine)（PRD FP-05 指定口径）。
"""

import math
import re
from collections import Counter

_PUNCT_RE = re.compile(r"[^\w\u4e00-\u9fff]+", re.UNICODE)
_WS_RE = re.compile(r"\s+", re.UNICODE)

CJK_RANGE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]")


def normalize(text):
    t = _WS_RE.sub(" ", (text or "").strip().lower())
    return t


def _cjk_share(text):
    if not text:
        return 0.0
    n = sum(1 for ch in text if CJK_RANGE.match(ch))
    return n / float(max(1, len(text)))


def word_tokens(text):
    """中英混合分词：ASCII 词按分隔符切词，中文串用字符 2-gram。

    中文没有空格，若只按空白切词，整段中文会变成一个 term，导致 TF-IDF 失效。
    """
    t = normalize(text)
    tokens = []
    buf = []
    cjk_run = []

    def flush_cjk():
        if cjk_run:
            tokens.extend(_grams("".join(cjk_run), 2))
            del cjk_run[:]

    def flush_buf():
        if buf:
            tokens.append("".join(buf))
            del buf[:]

    for ch in t:
        if CJK_RANGE.match(ch):
            flush_buf()
            cjk_run.append(ch)
        elif ch.isalnum() or ch == "_":
            flush_cjk()
            buf.append(ch)
        else:
            flush_cjk()
            flush_buf()
    flush_cjk()
    flush_buf()
    return [w for w in tokens if w]


def _grams(text, n):
    if len(text) <= n:
        return [text] if text else []
    return [text[i:i + n] for i in range(len(text) - n + 1)]


def char_ngrams(text, n=3):
    t = normalize(text).replace(" ", "")
    return set(_grams(t, n))


def jaccard(a_set, b_set):
    if not a_set and not b_set:
        return 1.0
    if not a_set or not b_set:
        return 0.0
    inter = len(a_set & b_set)
    union = len(a_set | b_set)
    return inter / float(union)


def jaccard_3gram(a, b):
    return jaccard(char_ngrams(a, 3), char_ngrams(b, 3))


def _term_freq(text):
    return Counter(word_tokens(text))


def build_idf(docs):
    """docs: list[str] -> {term: idf}。纯 Python，tf-idf 教科书公式 +1 平滑。"""
    n_docs = float(len(docs)) or 1.0
    df = Counter()
    tfs = [_term_freq(d) for d in docs]
    for tf in tfs:
        for term in tf:
            df[term] += 1
    return {t: (math.log((n_docs + 1.0) / (c + 1.0)) + 1.0) for t, c in df.items()}


def _l2(vec):
    return math.sqrt(sum(v * v for v in vec.values()))


def tfidf_vector(text, idf):
    tf = _term_freq(text)
    if not tf:
        return {}
    max_tf = float(max(tf.values())) or 1.0
    vec = {}
    for term, cnt in tf.items():
        w = (0.5 + 0.5 * (cnt / max_tf)) * float(idf.get(term, 1.0))
        vec[term] = w
    return vec


def cosine(vec_a, vec_b):
    if not vec_a or not vec_b:
        return 0.0
    common = set(vec_a) & set(vec_b)
    if not common:
        return 0.0
    num = sum(vec_a[t] * vec_b[t] for t in common)
    dena = _l2(vec_a)
    denb = _l2(vec_b)
    if dena == 0.0 or denb == 0.0:
        return 0.0
    return num / (dena * denb)


def similarity(a, b, idf=None):
    """返回 {"jaccard":x, "cosine":y, "similarity":max(x,y), "metric":哪个胜出}"""
    j = jaccard_3gram(a, b)
    if idf is None:
        idf = build_idf([a, b])
    c = cosine(tfidf_vector(a, idf), tfidf_vector(b, idf))
    sim = max(j, c)
    metric = "jaccard_3gram" if j >= c else "tfidf_cosine"
    return {"jaccard_3gram": round(j, 4), "tfidf_cosine": round(c, 4),
            "similarity": round(sim, 4), "metric": metric}


def pairwise(texts, idf=None):
    """返回 [(i,j,sim_dict)...]，i<j。确定性：输入顺序固定则结果固定。"""
    idf = idf or build_idf(texts)
    out = []
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            d = similarity(texts[i], texts[j], idf)
            d["i"] = i
            d["j"] = j
            out.append(d)
    return out


def self_test():
    checks = []

    def chk(name, cond):
        checks.append((name, bool(cond)))

    a = "Use idempotency keys plus optimistic locking to prevent oversell."
    b = "Use idempotency keys plus optimistic locking to prevent overselling."
    c = "Rewrite the whole service in Rust with a new queue."
    same = similarity(a, b)
    diff = similarity(a, c)
    chk("近似文本相似度高(>0.6)", same["similarity"] > 0.6)
    chk("异构文本相似度低(<0.4)", diff["similarity"] < 0.4)
    chk("相似文本 > 异构文本", same["similarity"] > diff["similarity"])
    chk("完全相同文本 = 1.0", similarity(a, a)["similarity"] == 1.0)
    zh1 = "采用幂等键与乐观锁防止超卖"
    zh2 = "采用幂等键与乐观锁防止超卖现象"
    chk("中文近似可被识别(>0.5)", similarity(zh1, zh2)["similarity"] > 0.5)
    chk("中文异构低相似(<0.4)", similarity(zh1, "整个服务改用 Rust 重写队列")["similarity"] < 0.4)
    chk("pairwise 数量 = n(n-1)/2", len(pairwise([a, b, c])) == 3)
    pw1 = pairwise([a, b, c])
    pw2 = pairwise([a, b, c])
    chk("pairwise 幂等", pw1 == pw2)
    return checks
