# -*- coding: utf-8 -*-
"""schema 版本号、事实源加载（tech_spec.json）、结构化记录校验。

单一事实源（公理Ⅳ）：所有阈值/常量只在 references/tech_spec.json 定义一处，
脚本一律从这里取；references/TECH_SPEC.md 是人类可读镜像，由 consistency_check.py 校验二者一致。
"""

import json
from pathlib import Path

# ---- 版本号（Trace/记录格式稳定性是测评做过程对比的前提）----
PACKAGE_VERSION = "0.1.0"
SCHEMA_VERSION = "1.0"
TRACE_SCHEMA = "trace.v1"
RUN_SCHEMA = "run.v1"
STRATEGY_SCHEMA = "strategy.v1"
STATE_SCHEMA = "state.v1"

TRACE_REQUIRED = ["schema_version", "ts", "run_id", "seq", "stage", "step", "status"]
RUN_REQUIRED = [
    "schema_version", "run_id", "ts", "task_class", "tier",
    "candidates_total", "candidates_unique", "coverage_rate",
    "claims_total", "claims_evidenced", "tokens_in", "tokens_out",
    "tokens_source", "redline_hits", "strategy_hits", "outcome", "failure_mode",
]
OUTCOME_ALLOWED = ["accepted", "rework", "failed", "abandoned"]

# ---- <｜hy_place▁holder▁no▁813｜> PRD §11 回填的接口占位（O-1 / O-2 / O-3）----
PENDING_BACKFILL = {
    "O-1": "SKILL.md frontmatter.description 最终措辞",
    "O-2": "成功信号分级与策略晋升门槛（tech_spec.strategy.signals / promotion）",
    "O-3": "预算档位 S/M/L 数值（tech_spec.budget.bands）",
}


def spec_path(root=None):
    from . import paths
    return (paths.skill_root() if root is None else Path(root)) / "references" / "tech_spec.json"


_SPEC_CACHE = {}


def load_spec(root=None):
    """加载 tech_spec.json（唯一事实源）。缺失时返回内置默认值并记录 degrade。"""
    p = spec_path(root)
    try:
        key = str(p) + "@" + str(p.stat().st_mtime)
    except Exception:
        key = str(p)
    if key in _SPEC_CACHE:
        return _SPEC_CACHE[key]
    spec, incident = None, None
    try:
        with open(str(p), "r", encoding="utf-8") as fh:
            spec = json.load(fh)
    except Exception as exc:
        spec = _DEFAULT_SPEC
        incident = {"field": "tech_spec", "error": "%s: %s" % (type(exc).__name__, exc),
                    "fallback": "builtin_defaults"}
    data = {"spec": spec, "incident": incident, "path": str(p)}
    _SPEC_CACHE[key] = data
    return data


def spec_get(dotted, root=None, default=None):
    """按 a.b.c 路径取值；缺失返回 default 且不抛异常。"""
    node = load_spec(root)["spec"]
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


# ---------------- 其他参考配置源（§11 回填新增）----------------
#
# 为什么把 budget-bands / signal-model 与 tech_spec 分开：
# 这两份是「待拍板项（P-1 / P-2）的开关面板」，切换口径时**只动配置不动代码**；
# tech_spec 保持纯阈值清单。二者都由 load_reference 统一加载，缺失时一律显式降级。

BAND_SCHEMA = "budget_bands.v1"
SIGNAL_SCHEMA = "signal_model.v1"
REDLINE_SCHEMA = "redline.v1"

_REF_CACHE = {}


def reference_path(filename, root=None):
    from . import paths
    return (paths.skill_root() if root is None else Path(root)) / "references" / filename


def load_reference(filename, root=None, fallback=None):
    """通用参考 JSON 加载器。返回 {"data":..., "incident":..., "path":...}。

    与 load_spec 的区别：这里的配置没有内置数值兜底——**数值缺失时必须降级而不是拍脑袋**，
    因此 fallback 默认为 None，由调用方决定降级行为（这是 no-voodoo-constants 的强制点）。
    """
    p = reference_path(filename, root)
    try:
        key = str(p) + "@" + str(p.stat().st_mtime)
    except Exception:
        key = str(p)
    if key in _REF_CACHE:
        return _REF_CACHE[key]
    data, incident = None, None
    try:
        with open(str(p), "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:
        data = fallback
        incident = {"field": filename, "error": "%s: %s" % (type(exc).__name__, exc),
                    "fallback": "none" if fallback is None else "builtin"}
    res = {"data": data, "incident": incident, "path": str(p)}
    _REF_CACHE[key] = res
    return res


# ---- O-3 / P-1：预算档位（唯一配置源 references/budget-bands.json）----

def band_cfg(root=None):
    return load_reference("budget-bands.json", root)["data"] or {}


def _resolve_band(name, root=None):
    """把 'M' / 'Standard' 统一成 band 代号 S|M|L；无法识别返回 None。"""
    cfg = band_cfg(root)
    if not cfg:
        return None
    name = str(name or "").strip()
    if name in cfg.get("bands", {}):
        return name
    return (cfg.get("tier_to_band") or {}).get(name)


def band_get(name, key=None, root=None, default=None):
    """取档位配置。band_get("M")->全量 dict；band_get("Standard","cap_chars")->30000。"""
    code = _resolve_band(name, root)
    if code is None:
        return default
    node = (band_cfg(root).get("bands") or {}).get(code) or {}
    if key is None:
        return node
    return node.get(key, default)


def band_tier(name, root=None):
    code = _resolve_band(name, root)
    if code is None:
        return None
    return (band_cfg(root).get("band_to_tier") or {}).get(code)


def chars_per_token_safe(root=None):
    """§11.2.1 唯一换算常数。取不到就用显式降级值并在 incident 里留痕（禁止魔法数字）。"""
    res = load_reference("budget-bands.json", root)
    cfg = res["data"] or {}
    val = cfg.get("chars_per_token_safe")
    if isinstance(val, (int, float)) and float(val) > 0:
        return float(val), None
    return 2.5, {"field": "chars_per_token_safe", "error": res["incident"] or "missing",
                 "fallback": "builtin 2.5", "level": "degraded"}


def band_water_levels(root=None):
    return (band_cfg(root).get("water_levels") or
            {"W1": {"ratio": 0.8}, "W2": {"ratio": 1.0}, "W3": {"ratio": 1.2}})


def band_downgrade(name, root=None):
    """只降不升：返回下一档代号；已是最小档返回自身（并标记 floor=True）。"""
    cfg = band_cfg(root)
    order = cfg.get("downgrade_order") or ["L", "M", "S"]
    code = _resolve_band(name, root)
    if code not in order:
        return code, True
    idx = order.index(code)
    if idx >= len(order) - 1:
        return code, True
    return order[idx + 1], False


# ---- O-2 / P-2：信号模型（唯一配置源 references/signal-model.json）----

def signal_cfg(root=None):
    return load_reference("signal-model.json", root)["data"] or {}


def signal_get(dotted, root=None, default=None):
    node = signal_cfg(root)
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def signals_index(root=None):
    """返回 {signal_id: signal_spec}。"""
    return dict((s.get("id"), s) for s in (signal_cfg(root).get("signals") or []))


def feedback_channel_factor(channel, root=None):
    """P-2 双通道折权系数返回 (factor, note)。未配置或未知通道 -> (1.0, 说明)。"""
    cfg = signal_cfg(root).get("feedback_channels") or {}
    active = cfg.get("active") or "double_channel"
    channels = cfg.get("channels") or {}
    if active == "explicit_only" and channel != "explicit_command":
        return 0.0, "P-2 已切到 explicit_only：非显式命令信号只进日志，不参与晋升计算"
    spec = channels.get(channel or "explicit_command") or {"weight_factor": 1.0}
    return float(spec.get("weight_factor", 1.0)), channel or "explicit_command"


def backfill_status():
    """返回 O-1/O-2/O-3 的回填状态机器可读摘要（供 doctor / consistency_check 使用）。

    注意：本函数不再硬编码「已回填」结论，而是**真实读取** tech_spec.json 的
    pending_backfill[k].status 字段。谎报状态会直接破坏 T5（禁止编造）与 RL-10
    （沉淀物与产物同步），故此处只做透传，不替任何条目背书。
    """
    spec = load_spec()["spec"].get("pending_backfill") or {}
    out = {}
    for k in ("O-1", "O-2", "O-3"):
        node = spec.get(k) or {}
        raw = node.get("status", "unknown")
        out[k] = {
            "item": node.get("item", PENDING_BACKFILL.get(k, k)),
            "status": raw,
            "raw_status": raw,
            "backfilled": ("已回填" in raw),
        }
    return out


def missing_fields(record, required):
    return [k for k in required if k not in record]


def validate_record(record, required, allowed_outcome=True):
    """返回 (ok, problems)。ok=False 时调用方应当报错而非静默。"""
    problems = []
    miss = missing_fields(record, required)
    if miss:
        problems.append({"type": "missing_fields", "fields": miss})
    if allowed_outcome:
        oc = record.get("outcome", None)
        if oc is not None and oc not in OUTCOME_ALLOWED:
            problems.append({"type": "bad_enum", "field": "outcome", "value": oc,
                             "allowed": OUTCOME_ALLOWED})
    if record.get("schema_version") is not None and record.get("schema_version") != RUN_SCHEMA:
        problems.append({"type": "schema_mismatch", "expected": RUN_SCHEMA,
                         "got": record.get("schema_version")})
    return (len(problems) == 0), problems


_DEFAULT_SPEC = {
    "_note": "builtin fallback: references/tech_spec.json 缺失或损坏时的降级值",
    "budget": {"tier_caps_tokens": {"Lite": 2000, "Standard": 8000, "Deep": 20000},
               "warn_ratio": 0.8},
    "token_model": {"chars_per_token": {"en": 4.0, "code": 3.0, "json": 2.6, "cjk": 1.2},
                    "safety": {"base": 1.15, "low_confidence_extra": 1.15},
                    "calibration": {"beta": 0.3, "min_samples_high_confidence": 20}},
    "dedupe": {"threshold": 0.85, "min_unique_ratio": 0.6, "min_viewpoint_dims": 3},
    "coverage": {"target_rate": 0.9, "max_backfill_rounds": 2},
    "claims": {"min_evidenced_ratio": 0.7},
    "gating": {"weights": {"U": 2.0, "C": 2.0, "I": 1.5, "V": 1.0, "R": 1.0},
               "thresholds": {"Deep": 6.0, "Standard": 3.0, "Lite": 1.0},
               "force_trigger_I": 2, "min_base_tokens": 2000},
    "strategy": {"index_max_lines": 100, "max_inject": 3,
                 "promotion": {"min_hits": 3, "min_success_rate": 0.7, "cooldown_hours": 24},
                 "capacity": {"promoted_max": 50, "pending_max": 200, "decay_per_day": 0.03,
                              "retire_days": 90}},
    "compression": {"default_lossy": False},
    "cache": {"enabled": False, "p2_stub": True},
}
